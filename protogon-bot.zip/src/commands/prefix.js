const {
  EmbedBuilder,
  Colors,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const { canManageGuild, isAdmin, canManageWithConfig } = require("../util");
const {
  parseDuration,
  canMod,
  needPerm,
  timeoutMember,
  kickMember,
  banMember,
  purgeChannel,
} = require("../handlers/modTools");

const { isLocked, markLocked, unlockGuild } = require("../lockdown");

const MODULES = [
  "massBan",
  "massKick",
  "massJoin",
  "massChannelCreate",
  "massChannelDelete",
  "massRoleCreate",
  "massRoleDelete",
  "massMessageDelete",
  "spam",
  "mention",
  "badword",
  "attachment",
  "invite",
  "malware",
];

function noPerm(message) {
  return message.reply(
    "❌ Bạn cần quyền **Quản lý server** (Manage Guild) để dùng lệnh này.",
  );
}

async function handleHelp(client, message) {
  const embed = new EmbedBuilder()
    .setColor(Colors.Aqua)
    .setTitle("🧭 Danh sách lệnh")
    .setDescription(
      [
        "**Prefix** `!` (đổi bằng `!prefix set <kí tự>`)",
        "",
        "```",
        "!help                  - danh sách lệnh",
        "!ping                  - kiểm tra độ trễ",
        "!prefix                - xem prefix",
        "!prefix set ^          - đổi prefix thành ^",
        "!autoreply list        - danh sách rule",
        "!autoreply add <tên> keyword <từ khóa> | <nội dung>",
        "!autoreply add <tên> mention | <nội dung>",
        "!autoreply remove <tên>",
        "!antinuke on|off       - bật/tắt chống nuke",
        "!antinuke status       - trạng thái",
        "!antinuke module <tên> on|off",
        "!antinuke unlock       - mở khóa kênh ngay",
        "!lockdown on|off       - khóa kênh tự động khi raid",
        "!heat                  - xem nhiệt độ & warn tích lũy",
        "!badword add <từ>      - thêm từ ngữ xấu",
        "!badword remove <từ>   - xóa từ ngữ xấu",
        "!badword list          - danh sách từ ngữ xấu",
        "!heat                  - xem mức nhiệt độ vi phạm",
        "!timeout @user 10m [lý do] - tạm khóa thành viên",
        "!kick @user [lý do]    - kick thành viên",
        "!ban @user [lý do]     - ban thành viên (--days 7 xóa tin nhắn)",
        "!purge <số>            - xóa hàng loạt tin nhắn",
        "!giveaway start <Tên> | <Giải thưởng> | <thời lượng>",
        "!giveaway list | end <tên>",
        "!setlog #kênh          - đặt kênh log",
        "```",
      ].join("\n"),
    )
    .setFooter({ text: "Slash command tương đương: /help /prefix /autoreply /antinuke /badword /heat /mod /giveaway /setup" });
  await message.reply({ embeds: [embed] });
}

async function handlePing(client, message) {
  const sent = await message.reply("🏓 Đang đo độ trễ…");
  const ws = Math.round(client.ws.ping);
  await sent.edit(`🏓 Pong! **${ws}ms** (WebSocket)`);
}

async function handlePrefix(client, message, args, config, store) {
  const prefix = config.prefix || "!";
  if (args[0] !== "set" || args.length < 2) {
    return message.reply(`Prefix hiện tại: \`${prefix}\``);
  }
  if (!canManageGuild(message.member)) return noPerm(message);
  const next = args[1];
  if (!/^[!^$#&%]{1,3}$/.test(next)) {
    return message.reply("Prefix phải là 1-3 ký tự đặc biệt (ví dụ: `!`, `^`, `!!`).");
  }
  await store.client.mutation("bot_writes:botUpdateSettings", {
    guildId: message.guild.id,
    prefix: next,
  });
  store.invalidate(message.guild.id);
  await message.reply(`✅ Đã đổi prefix thành \`${next}\`. Lệnh: \`${next}help\``);
}

async function handleAutoReply(client, message, args, config, store) {
  const sub = args[0]?.toLowerCase();

  if (sub === "list") {
    const rules = config.autoReplies || [];
    if (rules.length === 0) return message.reply("Chưa có rule auto reply nào.");
    const lines = rules.map(
      (r, i) =>
        `${i + 1}. **${r.name}** — ${r.triggerType === "mention" ? "@mention" : `từ khóa: ${r.keywords.join(", ")}`} — ${r.enabled ? "✅" : "⏸️"}`,
    );
    const embed = new EmbedBuilder()
      .setColor(Colors.Aqua)
      .setTitle(`📋 Auto reply (${rules.length})`)
      .setDescription(lines.join("\n").slice(0, 4000));
    return message.reply({ embeds: [embed] });
  }

  // Cho phép quyền Manage Guild/Administrator hoặc role Mod/Admin đã cấu hình.
  if (!canManageWithConfig(message.member, config)) {
    return message.reply(
      "❌ Bạn cần quyền **Quản lý server** hoặc role **Mod/Admin** của server để dùng lệnh này.",
    );
  }

  if (sub === "remove") {
    const name = args[1];
    if (!name) return message.reply("Cú pháp: `!autoreply remove <tên>`");
    await store.client.mutation("bot_writes:botAutoReplyRemove", {
      guildId: message.guild.id,
      name,
    });
    store.invalidate(message.guild.id);
    return message.reply(`✅ Đã xóa rule \`${name}\``);
  }

  if (sub === "add") {
    // !autoreply add <name> keyword <kw1,kw2> | <response>
    // !autoreply add <name> mention | <response>
    const name = args[1];
    const trigger = args[2]?.toLowerCase();
    if (!name || !trigger) {
      return message.reply(
        "Cú pháp:\n`!autoreply add <tên> keyword <từ khóa, cách nhau phẩy> | <nội dung trả lời>`\n`!autoreply add <tên> mention | <nội dung trả lời>`",
      );
    }
    const pipeIndex = args.indexOf("|");
    if (pipeIndex === -1) return message.reply("Thiếu phần `| <nội dung trả lời>`");
    const response = args.slice(pipeIndex + 1).join(" ");
    if (!response.trim()) return message.reply("Nội dung trả lời không được để trống.");
    const payload = {
      guildId: message.guild.id,
      name,
      triggerType: trigger === "mention" ? "mention" : "keyword",
      keywords:
        trigger === "mention" ? [] : args.slice(3, pipeIndex).join(" ").split(",").map((k) => k.trim()).filter(Boolean),
      response,
      channels: [],
      cooldownSeconds: 30,
      enabled: true,
    };
    if (payload.triggerType === "keyword" && payload.keywords.length === 0) {
      return message.reply("Cần ít nhất một từ khóa.");
    }
    try {
      await store.client.mutation("bot_writes:botAutoReplyUpsert", payload);
    } catch (err) {
      return message.reply(`❌ ${err.message}`);
    }
    store.invalidate(message.guild.id);
    return message.reply(`✅ Đã lưu rule \`${name}\` (thêm mới hoặc cập nhật)`);
  }

  return message.reply("Cú pháp: `!autoreply add/list/remove`");
}

async function handleAntinuke(client, message, args, config, store) {
  const sub = args[0]?.toLowerCase();

  if (sub === "status" || !sub) {
    const modules = config.modules || [];
    const lines = modules.map(
      (m) => `${m.enabled ? "✅" : "⏸️"} \`${m.module}\` — ngưỡng ${m.threshold} lần/${m.windowSeconds}s — ${m.punish}`,
    );
    const embed = new EmbedBuilder()
      .setColor(config.antinukeEnabled ? Colors.Green : Colors.Red)
      .setTitle(`🛡️ Chống nuke: ${config.antinukeEnabled ? "ĐANG BẬT" : "ĐÃ TẮT"}`)
      .setDescription(lines.join("\n") || "Chưa có module nào.");
    return message.reply({ embeds: [embed] });
  }

  if (!canManageGuild(message.member) && !isAdmin(message.member)) return noPerm(message);

  if (sub === "unlock") {
    if (!isLocked(message.guild.id)) {
      const cfg = await store.getConfig(message.guild.id);
      if (!cfg?.lockdownUntil || cfg.lockdownUntil <= Date.now()) {
        return message.reply("Server hiện không ở trạng thái khóa kênh.");
      }
      markLocked(message.guild.id);
    }
    const cfg = await store.getConfig(message.guild.id);
    await unlockGuild(client, message.guild, cfg, store);
    return message.reply("🔓 Đã mở khóa kênh.");
  }

  if (sub === "on" || sub === "off") {
    await store.client.mutation("bot_writes:botSetAntinuke", {
      guildId: message.guild.id,
      enabled: sub === "on",
    });
    store.invalidate(message.guild.id);
    return message.reply(`✅ Đã ${sub === "on" ? "bật" : "tắt"} chống nuke.`);
  }

  if (sub === "module") {
    const name = args[1];
    const value = args[2]?.toLowerCase();
    if (!MODULES.includes(name) || !["on", "off"].includes(value)) {
      return message.reply(
        `Cú pháp: \`!antinuke module <${MODULES.join("|")}> <on|off>\``,
      );
    }
    await store.client.mutation("bot_writes:botModuleUpdate", {
      guildId: message.guild.id,
      module: name,
      enabled: value === "on",
    });
    store.invalidate(message.guild.id);
    return message.reply(`✅ Module \`${name}\` đã ${value === "on" ? "bật" : "tắt"}.`);
  }

  return message.reply("Cú pháp: `!antinuke on|off|status|module <tên> <on|off>|unlock`");
}

async function handleLockdown(client, message, args, config, store) {
  if (!canManageGuild(message.member)) return noPerm(message);
  const sub = args[0]?.toLowerCase();
  if (sub !== "on" && sub !== "off") {
    return message.reply("Cú pháp: `!lockdown on|off`");
  }
  await store.client.mutation("bot_writes:botUpdateLockdown", {
    guildId: message.guild.id,
    enabled: sub === "on",
  });
  store.invalidate(message.guild.id);
  return message.reply(
    sub === "on"
      ? "✅ Khóa kênh tự động khi raid đã bật."
      : "✅ Khóa kênh tự động khi raid đã tắt.",
  );
}

async function handleBadword(client, message, args, config, store) {
  if (!canManageGuild(message.member)) return noPerm(message);
  const sub = args[0]?.toLowerCase();
  const words = [...(config.badWords || [])];

  if (sub === "list" || !sub) {
    if (words.length === 0) {
      return message.reply("Danh sách từ ngữ xấu đang trống — dùng `!badword add <từ>` hoặc dashboard.");
    }
    const embed = new EmbedBuilder()
      .setColor(Colors.Aqua)
      .setTitle(`📋 Từ ngữ xấu (${words.length})`)
      .setDescription(words.map((w) => `\`${w}\``).join(", ").slice(0, 4000));
    return message.reply({ embeds: [embed] });
  }

  if (sub === "add") {
    const word = args.slice(1).join(" ").trim().toLowerCase();
    if (!word) return message.reply("Cú pháp: `!badword add <từ cần chặn>`");
    if (word.length > 40) return message.reply("Từ ngữ tối đa 40 ký tự.");
    if (words.includes(word)) return message.reply(`\`${word}\` đã có trong danh sách.`);
    if (words.length >= 100) return message.reply("Danh sách đã đạt tối đa 100 từ.");
    words.push(word);
    await store.client.mutation("bot_writes:botUpdateSettings", {
      guildId: message.guild.id,
      badWords: words,
    });
    store.invalidate(message.guild.id);
    return message.reply(`✅ Đã thêm \`${word}\` (${words.length} từ).`);
  }

  if (sub === "remove") {
    const word = args.slice(1).join(" ").trim().toLowerCase();
    const next = words.filter((w) => w !== word);
    if (next.length === words.length) {
      return message.reply(`Không tìm thấy \`${word}\` trong danh sách.`);
    }
    await store.client.mutation("bot_writes:botUpdateSettings", {
      guildId: message.guild.id,
      badWords: next,
    });
    store.invalidate(message.guild.id);
    return message.reply(`✅ Đã xóa \`${word}\` khỏi danh sách.`);
  }

  return message.reply("Cú pháp: `!badword add|remove|list`");
}

async function handleHeat(client, message, args, config, store) {
  const s = {
    enabled: config.heatEnabled !== false,
    decayPerMin: config.heatDecayPerMin ?? 3,
    warnAt: config.heatWarnAt ?? 25,
    timeoutAt: config.heatTimeoutAt ?? 40,
    kickAt: config.heatKickAt ?? 70,
    banAt: config.heatBanAt ?? 90,
    repeatMultiplier: config.heatRepeatMultiplier ?? 2,
    repeatWindowMin: config.heatRepeatWindowMin ?? 30,
    warnStrikeLimit: config.warnStrikeLimit ?? 3,
    warnStrikeWindowMin: config.warnStrikeWindowMin ?? 60,
    warnStrikePunish: config.warnStrikePunish ?? "timeout",
  };
  const top = config.heatStates || [];
  const safety = config.safetyPercent ?? 100;
  const tier = (heat) =>
    heat >= s.banAt ? "🚫 Ban" : heat >= s.kickAt ? "👢 Kick" : heat >= s.timeoutAt ? "⏸️ Tạm khóa" : "⚠️ Theo dõi";
  const embed = new EmbedBuilder()
    .setColor(safety >= 70 ? Colors.Green : safety >= 40 ? Colors.Yellow : Colors.Red)
    .setTitle(`🌡️ Nhiệt độ vi phạm: ${safety}% an toàn`)
    .setDescription(
      [
        s.enabled
          ? `Hệ thống nhiệt **đang bật** — giảm ${s.decayPerMin} điểm/phút, tái phạm tăng **x${s.repeatMultiplier}** trong ${s.repeatWindowMin} phút.`
          : `Hệ thống nhiệt **đang tắt**.`,
        `Ngưỡng: cảnh báo **${s.warnAt}** · tạm khóa **${s.timeoutAt}** · kick **${s.kickAt}** · ban **${s.banAt}** (tối đa 100).`,
        s.warnStrikeLimit
          ? `Warn tích lũy: **${s.warnStrikeLimit}** lần trong ${s.warnStrikeWindowMin} phút → **${s.warnStrikePunish}**.`
          : `Warn tích lũy: **đang tắt**.`,
      ].join("\n"),
    );
  if (top.length > 0) {
    embed.addFields({
      name: "Thành viên nóng nhất",
      value: top
        .slice(0, 10)
        .map((h) => `<@${h.userId}> — **${h.heat}/100** — ${tier(h.heat)}`)
        .join("\n")
        .slice(0, 1024),
    });
  } else {
    embed.addFields({ name: "Thành viên nóng nhất", value: "Chưa có vi phạm nào — server rất an toàn 🎉" });
  }
  return message.reply({ embeds: [embed] });
}

async function handleSetlog(client, message, args, config, store) {
  if (!canManageGuild(message.member)) return noPerm(message);
  const channel = message.mentions.channels.first();
  if (!channel) return message.reply("Hãy tag kênh log, ví dụ: `!setlog #logs`");
  await store.client.mutation("bot_writes:botUpdateSettings", {
    guildId: message.guild.id,
    logChannelId: channel.id,
  });
  store.invalidate(message.guild.id);
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setStyle(ButtonStyle.Link)
      .setLabel("Mở kênh log")
      .setURL(`https://discord.com/channels/${message.guild.id}/${channel.id}`),
  );
  await message.reply({
    content: `✅ Kênh log đã đặt là ${channel}. Cảnh báo chống nuke sẽ được gửi tại đây.`,
    components: [row],
  });
}

async function handleTimeout(client, message, args, config, store) {
  if (!canMod(message, config)) return needPerm(message.channel);
  const member = message.mentions.members.first();
  const minutes = parseDuration(args[1]);
  if (!member) return message.reply("Tag thành viên cần timeout: `!timeout @user 10m [lý do]`");
  if (!minutes) {
    return message.reply("Thời lượng không hợp lệ (ví dụ: `10m`, `2h`, `1d`, hoặc số phút). Tối đa 7 ngày.");
  }
  const reason = args.slice(2).join(" ").trim() || undefined;
  try {
    const out = await timeoutMember({
      guild: message.guild,
      member,
      executor: message.author,
      minutes,
      reason,
      guildConfig: config,
      store,
    });
    return message.reply(`✅ ${out}`);
  } catch (e) {
    return message.reply(`❌ Không thể timeout: ${e.message}`);
  }
}

async function handlePurge(client, message, args, config, store) {
  if (!canMod(message, config)) return needPerm(message.channel);
  const count = parseInt(args[0], 10);
  if (!Number.isFinite(count) || count <= 0) {
    return message.reply("Cú pháp: `!purge <số tin nhắn tối đa 100>`");
  }
  try {
    const out = await purgeChannel(message.channel, count, message.author, config, store);
    const sent = await message.reply(`✅ ${out}`);
    setTimeout(() => sent.delete().catch(() => {}), 5000);
  } catch (e) {
    return message.reply(`❌ Không thể purge: ${e.message}`);
  }
}

async function handleKick(client, message, args, config, store) {
  if (!canMod(message, config)) return needPerm(message.channel);
  const member = message.mentions.members.first();
  if (!member) return message.reply("Tag thành viên cần kick: `!kick @user [lý do]`");
  const reason = args.slice(1).join(" ").trim() || undefined;
  try {
    const out = await kickMember({
      guild: message.guild,
      member,
      executor: message.author,
      reason,
      guildConfig: config,
      store,
    });
    return message.reply(`✅ ${out}`);
  } catch (e) {
    return message.reply(`❌ Không thể kick: ${e.message}`);
  }
}

async function handleBan(client, message, args, config, store) {
  if (!canMod(message, config)) return needPerm(message.channel);
  const member = message.mentions.members.first();
  if (!member) return message.reply("Tag thành viên cần ban: `!ban @user [lý do]`");
  const rest = args.slice(1).join(" ");
  const daysMatch = /--days (\d+)/.exec(rest);
  const deleteDays = daysMatch ? Math.max(0, Math.min(7, parseInt(daysMatch[1], 10))) : 0;
  const reason = rest.replace(/--days \d+/, "").trim() || undefined;
  try {
    const out = await banMember({
      guild: message.guild,
      member,
      executor: message.author,
      reason,
      deleteDays,
      guildConfig: config,
      store,
    });
    return message.reply(`✅ ${out}`);
  } catch (e) {
    return message.reply(`❌ Không thể ban: ${e.message}`);
  }
}

async function handleGiveaway(client, message, args, config, store) {
  const sub = args[0]?.toLowerCase();

  if (sub === "list") {
    const giveaways = config.giveaways || [];
    if (giveaways.length === 0) {
      return message.reply("Chưa có giveaway nào — tạo bằng `!giveaway start` hoặc trên dashboard.");
    }
    const lines = giveaways
      .slice(0, 20)
      .map(
        (g) =>
          `${g.status === "active" ? "🎉" : g.status === "ended" ? "🏁" : "🚫"} **${g.title}** — ${g.entries?.length || 0} lượt tham gia — ${g.status}`,
      );
    const embed = new EmbedBuilder()
      .setColor(Colors.Aqua)
      .setTitle(`🎉 Giveaway (${giveaways.length})`)
      .setDescription(lines.join("\n").slice(0, 4000));
    return message.reply({ embeds: [embed] });
  }

  if (sub === "end") {
    if (!canMod(message, config)) return needPerm(message.channel);
    const name = args.slice(1).join(" ").trim();
    if (!name) return message.reply("Cú pháp: `!giveaway end <tên giveaway>`");
    const res = await store.client.mutation("hidden:botGiveawayEndNow", {
      guildId: message.guild.id,
      title: name,
    });
    store.invalidate(message.guild.id);
    return message.reply(
      res.ok
        ? `✅ Đã kết thúc giveaway "${name}" — bot sẽ chốt người thắng trong ~30 giây.`
        : `Không tìm thấy giveaway đang chạy tên "${name}".`,
    );
  }

  if (sub === "start") {
    if (!canMod(message, config)) return needPerm(message.channel);
    // !giveaway start <Tên> | <Giải thưởng> | <thời lượng> [số người thắng]
    const parts = args.slice(1).join(" ").split("|").map((p) => p.trim());
    if (parts.length < 3) {
      return message.reply(
        "Cú pháp: `!giveaway start <Tên> | <Giải thưởng> | <thời lượng: 5p, 1h, 1d, 60> [số người thắng, mặc định 1]`",
      );
    }
    const title = parts[0];
    const prize = parts[1];
    const minutes = parseDuration(parts[2]);
    const winnerCount = parseInt(parts[3] || "1", 10) || 1;
    if (!minutes) return message.reply("Thời lượng không hợp lệ (ví dụ: `30m`, `2h`, `1d`).");
    try {
      await store.client.mutation("hidden:botCreateGiveaway", {
        guildId: message.guild.id,
        channelId: message.channel.id,
        title: title.slice(0, 100),
        prize: prize.slice(0, 2000),
        winnerCount: Math.max(1, Math.min(20, winnerCount)),
        durationMinutes: minutes,
        dmWinners: true,
      });
      store.invalidate(message.guild.id);
      return message.reply(
        `🎉 Đã tạo giveaway "${title}" ngay tại kênh này — bot gửi embed trong ~30 giây!`,
      );
    } catch (e) {
      return message.reply(`❌ ${e.message}`);
    }
  }

  return message.reply(
    "Cú pháp: `!giveaway start <Tên> | <Giải thưởng> | <thời lượng> [số người thắng]` · `!giveaway list` · `!giveaway end <tên>`",
  );
}

module.exports = {
  help: handleHelp,
  ping: handlePing,
  prefix: handlePrefix,
  autoreply: handleAutoReply,
  antinuke: handleAntinuke,
  lockdown: handleLockdown,
  badword: handleBadword,
  heat: handleHeat,
  setlog: handleSetlog,
  timeout: handleTimeout,
  purge: handlePurge,
  kick: handleKick,
  ban: handleBan,
  giveaway: handleGiveaway,
};
