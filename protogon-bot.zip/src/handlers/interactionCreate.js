const { EmbedBuilder, Colors } = require("discord.js");
const { canManageGuild, isAdmin, canManageWithConfig } = require("../util");
const { isLocked, markLocked, unlockGuild } = require("../lockdown");
const {
  parseDuration,
  canMod,
  timeoutMember,
  kickMember,
  banMember,
  purgeChannel,
} = require("./modTools");

const MODULES = [
  "massBan",
  "massKick",
  "massJoin",
  "massChannelCreate",
  "massChannelDelete",
  "massRoleCreate",
  "massRoleDelete",
  "massMessageDelete",
  "spam",
  "mention",
  "badword",
  "attachment",
  "invite",
  "malware",
];

function needPerm(interaction) {
  return interaction.reply({
    content: "❌ Bạn không có quyền dùng lệnh này — cần quyền **Quản lý server** hoặc role **Mod/Admin** được cấu hình qua `/setup`.",
    ephemeral: true,
  });
}

module.exports = async function onInteractionCreate(client, interaction, store) {
  if (!interaction.isChatInputCommand()) return;

  const name = interaction.commandName;
  const guild = interaction.guild;
  if (!guild) {
    return interaction.reply({ content: "Lệnh này chỉ hoạt động trong server.", ephemeral: true });
  }

  switch (name) {
    case "ping": {
      const ws = Math.round(client.ws.ping);
      return interaction.reply({ content: `🏓 Pong! **${ws}ms** (WebSocket)`, ephemeral: true });
    }

    case "help": {
      const embed = new EmbedBuilder()
        .setColor(Colors.Aqua)
        .setTitle("🧭 Lệnh của Protogon")
        .setDescription(
          [
            "**Auto Reply** — `/autoreply add` tạo rule từ khóa hoặc @mention, `/autoreply list`, `/autoreply remove`",
            "**Chống nuke** — `/antinuke status`, `/antinuke on|off`, `/antinuke module`, `/antinuke unlock`, `/antinuke lockdown`",
            "**Lọc nội dung** — module \`badword\`, \`invite\`, \`attachment\`, \`mention\` (bật tắt trong `/antinuke module`) · `/badword add|remove|list` · `/heat status`",
            "**Mod tools** — `/mod timeout @user 10m [lý do]`, `/mod kick`, `/mod ban`, `/mod purge` (ghi log lý do + người thực hiện)",
            "**Giveaway** — `/giveaway start <tên> <giải thưởng> <thời lượng>`, `/giveaway list`, `/giveaway end`",
            "**Cấu hình** — `/setup log-channel`, `/setup mod-role`, `/setup admin-role`, `/prefix set`",
            "**Khác** — `/ping`",
          ].join("\n"),
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    case "prefix": {
      const set = interaction.options.getString("set");
      const config = await store.getConfig(guild.id);
      const current = config?.prefix || "!";
      if (!set) {
        return interaction.reply({ content: `Prefix hiện tại: \`${current}\``, ephemeral: true });
      }
      if (!canManageGuild(interaction.member)) return needPerm(interaction);
      if (!/^[!^$#&%]{1,3}$/.test(set)) {
        return interaction.reply({
          content: "Prefix phải là 1-3 ký tự đặc biệt (ví dụ: `!`, `^`).",
          ephemeral: true,
        });
      }
      await store.client.mutation("bot_writes:botUpdateSettings", { guildId: guild.id, prefix: set });
      store.invalidate(guild.id);
      return interaction.reply({
        content: `✅ Đã đổi prefix thành \`${set}\`. Lệnh text: \`${set}help\``,
        ephemeral: true,
      });
    }

    case "autoreply": {
      const sub = interaction.options.getSubcommand();
      const config = await store.getConfig(guild.id);

      if (sub === "list") {
        const rules = config?.autoReplies || [];
        if (rules.length === 0) {
          return interaction.reply({ content: "Chưa có rule auto reply nào.", ephemeral: true });
        }
        const lines = rules.map(
          (r) =>
            `• **${r.name}** — ${r.triggerType === "mention" ? "@mention" : r.keywords.join(", ")} — ${r.enabled ? "✅" : "⏸️"}`,
        );
        const embed = new EmbedBuilder()
          .setColor(Colors.Aqua)
          .setTitle(`📋 Auto reply (${rules.length})`)
          .setDescription(lines.join("\n").slice(0, 4000));
        return interaction.reply({ embeds: [embed], ephemeral: true });
      }

      // Mod/Admin (Manage Guild) hoặc role Mod/Admin được cấu hình qua /setup.
      if (!canManageWithConfig(interaction.member, config)) return needPerm(interaction);

      if (sub === "add") {
        const name = interaction.options.getString("name", true);
        const trigger = interaction.options.getString("trigger", true);
        const response = interaction.options.getString("response", true);
        const keywordsRaw = interaction.options.getString("keywords") ?? "";
        const cooldown = interaction.options.getInteger("cooldown") ?? 30;
        const payload = {
          guildId: guild.id,
          name,
          triggerType: trigger === "mention" ? "mention" : "keyword",
          keywords: keywordsRaw.split(",").map((k) => k.trim()).filter(Boolean),
          response,
          channels: [],
          cooldownSeconds: Math.max(0, cooldown),
          enabled: true,
        };
        if (payload.triggerType === "keyword" && payload.keywords.length === 0) {
          return interaction.reply({
            content: "Với loại `keyword` bạn cần nhập từ khóa (phân cách bằng dấu phẩy).",
            ephemeral: true,
          });
        }
        try {
          await store.client.mutation("bot_writes:botAutoReplyUpsert", payload);
        } catch (err) {
          return interaction.reply({ content: `❌ ${err.message}`, ephemeral: true });
        }
        store.invalidate(guild.id);
        return interaction.reply({
          content: `✅ Đã lưu rule \`${name}\` (thêm mới hoặc cập nhật) — bot trả lời: "${response.slice(0, 80)}${response.length > 80 ? "…" : ""}"`,
          ephemeral: true,
        });
      }

      if (sub === "remove") {
        const name = interaction.options.getString("name", true);
        await store.client.mutation("bot_writes:botAutoReplyRemove", {
          guildId: guild.id,
          name,
        });
        store.invalidate(guild.id);
        return interaction.reply({
          content: `✅ Đã xóa rule \`${name}\`.`,
          ephemeral: true,
        });
      }

      if (sub === "edit") {
        const name = interaction.options.getString("name", true);
        const response = interaction.options.getString("response");
        const cooldown = interaction.options.getInteger("cooldown");
        const rule = (config?.autoReplies || []).find((r) => r.name === name);
        if (!rule) {
          return interaction.reply({
            content: `Không tìm thấy rule \`${name}\`. Dùng \`/autoreply list\` để xem danh sách.`,
            ephemeral: true,
          });
        }
        await store.client.mutation("bot_writes:botAutoReplyUpsert", {
          guildId: guild.id,
          name,
          triggerType: rule.triggerType,
          keywords: rule.keywords,
          response: response ?? rule.response,
          channels: rule.channels || [],
          cooldownSeconds: cooldown !== null ? Math.max(0, cooldown) : rule.cooldownSeconds,
          enabled: rule.enabled,
        });
        store.invalidate(guild.id);
        return interaction.reply({
          content: `✅ Đã cập nhật rule \`${name}\`.`,
          ephemeral: true,
        });
      }
      return;
    }

    case "badword": {
      const sub = interaction.options.getSubcommand();
      const config = await store.getConfig(guild.id);
      const words = [...(config?.badWords || [])];

      if (sub === "list") {
        if (words.length === 0) {
          return interaction.reply({ content: "Danh sách từ ngữ xấu đang trống — dùng `/badword add` hoặc dashboard để thêm.", ephemeral: true });
        }
        const embed = new EmbedBuilder()
          .setColor(Colors.Aqua)
          .setTitle(`📋 Danh sách từ ngữ xấu (${words.length})`)
          .setDescription(words.map((w) => `\`${w}\``).join(", ").slice(0, 4000));
        return interaction.reply({ embeds: [embed], ephemeral: true });
      }

      if (!canManageGuild(interaction.member)) return needPerm(interaction);

      if (sub === "add") {
        const word = interaction.options.getString("word", true).trim().toLowerCase();
        if (!word) return interaction.reply({ content: "Từ ngữ không được để trống.", ephemeral: true });
        if (word.length > 40) {
          return interaction.reply({ content: "Từ ngữ tối đa 40 ký tự.", ephemeral: true });
        }
        if (words.includes(word)) {
          return interaction.reply({ content: `\`${word}\` đã có trong danh sách.`, ephemeral: true });
        }
        if (words.length >= 100) {
          return interaction.reply({ content: "Danh sách đã đạt tối đa 100 từ.", ephemeral: true });
        }
        words.push(word);
        await store.client.mutation("bot_writes:botUpdateSettings", {
          guildId: guild.id,
          badWords: words,
        });
        store.invalidate(guild.id);
        return interaction.reply({
          content: `✅ Đã thêm \`${word}\` vào danh sách từ ngữ xấu (${words.length} từ).`,
          ephemeral: true,
        });
      }

      if (sub === "remove") {
        const word = interaction.options.getString("word", true).trim().toLowerCase();
        const next = words.filter((w) => w !== word);
        if (next.length === words.length) {
          return interaction.reply({ content: `Không tìm thấy \`${word}\` trong danh sách.`, ephemeral: true });
        }
        await store.client.mutation("bot_writes:botUpdateSettings", {
          guildId: guild.id,
          badWords: next,
        });
        store.invalidate(guild.id);
        return interaction.reply({
          content: `✅ Đã xóa \`${word}\` khỏi danh sách từ ngữ xấu.`,
          ephemeral: true,
        });
      }
      return;
    }

    case "heat": {
      const config = await store.getConfig(guild.id);
      const s = {
        enabled: config?.heatEnabled !== false,
        decayPerMin: config?.heatDecayPerMin ?? 3,
        warnAt: config?.heatWarnAt ?? 25,
        timeoutAt: config?.heatTimeoutAt ?? 40,
        kickAt: config?.heatKickAt ?? 70,
        banAt: config?.heatBanAt ?? 90,
        repeatMultiplier: config?.heatRepeatMultiplier ?? 2,
        repeatWindowMin: config?.heatRepeatWindowMin ?? 30,
        warnStrikeLimit: config?.warnStrikeLimit ?? 3,
        warnStrikeWindowMin: config?.warnStrikeWindowMin ?? 60,
        warnStrikePunish: config?.warnStrikePunish ?? "timeout",
      };
      const top = config?.heatStates || [];
      const safety = config?.safetyPercent ?? 100;
      const tier = (heat) => (heat >= s.banAt ? "🚫 Ban" : heat >= s.kickAt ? "👢 Kick" : heat >= s.timeoutAt ? "⏸️ Tạm khóa" : "⚠️ Theo dõi");
      const embed = new EmbedBuilder()
        .setColor(safety >= 70 ? Colors.Green : safety >= 40 ? Colors.Yellow : Colors.Red)
        .setTitle(`🌡️ Nhiệt độ vi phạm: ${safety}% an toàn`)
        .setDescription(
          [
            s.enabled
              ? `Hệ thống nhiệt **đang bật** — giảm ${s.decayPerMin} điểm/phút, tái phạm tăng **x${s.repeatMultiplier}** trong ${s.repeatWindowMin} phút.`
              : `Hệ thống nhiệt **đang tắt**.`,
            `Ngưỡng: cảnh báo **${s.warnAt}** · tạm khóa **${s.timeoutAt}** · kick **${s.kickAt}** · ban **${s.banAt}** (tối đa 100).`,
            s.warnStrikeLimit
              ? `Warn tích lũy: **${s.warnStrikeLimit}** lần trong ${s.warnStrikeWindowMin} phút → **${s.warnStrikePunish}**.`
              : `Warn tích lũy: **đang tắt**.`,
          ].join("\n"),
        );
      if (top.length > 0) {
        embed.addFields({
          name: "Thành viên nóng nhất",
          value: top
            .slice(0, 10)
            .map((h) => `<@${h.userId}> — **${h.heat}/100** — ${tier(h.heat)}`)
            .join("\n")
            .slice(0, 1024),
        });
      } else {
        embed.addFields({ name: "Thành viên nóng nhất", value: "Chưa có vi phạm nào — server rất an toàn 🎉" });
      }
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    case "antinuke": {
      const sub = interaction.options.getSubcommand();

      if (sub === "status") {
        const config = await store.getConfig(guild.id);
        const modules = config?.modules || [];
        const lines = modules.map(
          (m) => `${m.enabled ? "✅" : "⏸️"} \`${m.module}\` — ${m.threshold} lần/${m.windowSeconds}s — ${m.punish}`,
        );
        const embed = new EmbedBuilder()
          .setColor(config?.antinukeEnabled ? Colors.Green : Colors.Red)
          .setTitle(`🛡️ Chống nuke: ${config?.antinukeEnabled ? "ĐANG BẬT" : "ĐÃ TẮT"}`)
          .setDescription(lines.join("\n") || "Chưa có module nào.");
        return interaction.reply({ embeds: [embed], ephemeral: true });
      }

      if (!canManageGuild(interaction.member) && !isAdmin(interaction.member)) return needPerm(interaction);

      if (sub === "unlock") {
        if (!isLocked(guild.id)) {
          const config = await store.getConfig(guild.id);
          if (!config?.lockdownUntil || config.lockdownUntil <= Date.now()) {
            return interaction.reply({
              content: "Server hiện không ở trạng thái khóa kênh.",
              ephemeral: true,
            });
          }
          markLocked(guild.id);
        }
        const config = await store.getConfig(guild.id);
        await unlockGuild(client, guild, config, store);
        return interaction.reply({
          content: "🔓 Đã mở khóa kênh.",
          ephemeral: true,
        });
      }

      if (sub === "lockdown") {
        const value = interaction.options.getString("value", true);
        if (!["on", "off"].includes(value)) {
          return interaction.reply({ content: "Giá trị phải là on hoặc off.", ephemeral: true });
        }
        await store.client.mutation("bot_writes:botUpdateLockdown", {
          guildId: guild.id,
          enabled: value === "on",
        });
        store.invalidate(guild.id);
        return interaction.reply({
          content: value === "on"
            ? "✅ Khóa kênh tự động khi raid đã bật."
            : "✅ Khóa kênh tự động khi raid đã tắt.",
          ephemeral: true,
        });
      }

      if (sub === "on" || sub === "off") {
        await store.client.mutation("bot_writes:botSetAntinuke", {
          guildId: guild.id,
          enabled: sub === "on",
        });
        store.invalidate(guild.id);
        return interaction.reply({
          content: `✅ Đã ${sub === "on" ? "bật" : "tắt"} chống nuke.`,
          ephemeral: true,
        });
      }

      if (sub === "module") {
        const moduleName = interaction.options.getString("module", true);
        const value = interaction.options.getString("value", true);
        if (!MODULES.includes(moduleName) || !["on", "off"].includes(value)) {
          return interaction.reply({
            content: `Module phải thuộc: ${MODULES.join(", ")} và giá trị là on|off.`,
            ephemeral: true,
          });
        }
        await store.client.mutation("bot_writes:botModuleUpdate", {
          guildId: guild.id,
          module: moduleName,
          enabled: value === "on",
        });
        store.invalidate(guild.id);
        return interaction.reply({
          content: `✅ Module \`${moduleName}\` đã ${value === "on" ? "bật" : "tắt"}.`,
          ephemeral: true,
        });
      }
      return;
    }

    case "mod": {
      const sub = interaction.options.getSubcommand();
      const config = await store.getConfig(guild.id);
      if (!canMod(interaction, config)) return needPerm(interaction);

      if (sub === "timeout") {
        const target = interaction.options.getMember("user");
        const minutes = parseDuration(interaction.options.getString("duration", true));
        const reason = interaction.options.getString("reason") || undefined;
        if (!target) {
          return interaction.reply({ content: "Không tìm thấy thành viên đó.", ephemeral: true });
        }
        if (!minutes) {
          return interaction.reply({
            content: "Thời lượng không hợp lệ (ví dụ: `10m`, `2h`, `1d`). Tối đa 7 ngày.",
            ephemeral: true,
          });
        }
        try {
          const out = await timeoutMember({
            guild,
            member: target,
            executor: interaction.user,
            minutes,
            reason,
            guildConfig: config,
            store,
          });
          return interaction.reply({ content: `✅ ${out}`, ephemeral: true });
        } catch (e) {
          return interaction.reply({ content: `❌ Không thể timeout: ${e.message}`, ephemeral: true });
        }
      }

      if (sub === "kick") {
        const target = interaction.options.getMember("user");
        const reason = interaction.options.getString("reason") || undefined;
        if (!target) {
          return interaction.reply({ content: "Không tìm thấy thành viên đó.", ephemeral: true });
        }
        try {
          const out = await kickMember({
            guild,
            member: target,
            executor: interaction.user,
            reason,
            guildConfig: config,
            store,
          });
          return interaction.reply({ content: `✅ ${out}`, ephemeral: true });
        } catch (e) {
          return interaction.reply({ content: `❌ Không thể kick: ${e.message}`, ephemeral: true });
        }
      }

      if (sub === "ban") {
        const target = interaction.options.getMember("user");
        const reason = interaction.options.getString("reason") || undefined;
        const deleteDays = Math.max(0, Math.min(7, interaction.options.getInteger("delete_days") ?? 0));
        if (!target) {
          return interaction.reply({ content: "Không tìm thấy thành viên đó.", ephemeral: true });
        }
        try {
          const out = await banMember({
            guild,
            member: target,
            executor: interaction.user,
            reason,
            deleteDays,
            guildConfig: config,
            store,
          });
          return interaction.reply({ content: `✅ ${out}`, ephemeral: true });
        } catch (e) {
          return interaction.reply({ content: `❌ Không thể ban: ${e.message}`, ephemeral: true });
        }
      }

      if (sub === "purge") {
        const count = interaction.options.getInteger("count", true);
        try {
          const out = await purgeChannel(interaction.channel, count, interaction.user, config, store);
          return interaction.reply({ content: `✅ ${out}`, ephemeral: true });
        } catch (e) {
          return interaction.reply({ content: `❌ Không thể purge: ${e.message}`, ephemeral: true });
        }
      }
      return;
    }

    case "giveaway": {
      const sub = interaction.options.getSubcommand();
      const config = await store.getConfig(guild.id);

      if (sub === "list") {
        const giveaways = config?.giveaways || [];
        if (giveaways.length === 0) {
          return interaction.reply({ content: "Chưa có giveaway nào.", ephemeral: true });
        }
        const lines = giveaways
          .slice(0, 20)
          .map((g) => `${g.status === "active" ? "🎉" : "🏁"} **${g.title}** — ${g.entries?.length || 0} lượt tham gia`);
        const embed = new EmbedBuilder()
          .setColor(Colors.Aqua)
          .setTitle(`🎉 Giveaway (${giveaways.length})`)
          .setDescription(lines.join("\n").slice(0, 4000));
        return interaction.reply({ embeds: [embed], ephemeral: true });
      }

      if (!canMod(interaction, config)) return needPerm(interaction);

      if (sub === "start") {
        const title = interaction.options.getString("title", true);
        const prize = interaction.options.getString("prize", true);
        const minutes = parseDuration(interaction.options.getString("duration", true));
        const winnerCount = Math.max(1, Math.min(20, interaction.options.getInteger("winners") ?? 1));
        const prizeRole = interaction.options.getRole("prize_role");
        if (!minutes) {
          return interaction.reply({
            content: "Thời lượng không hợp lệ (ví dụ: `30m`, `2h`, `1d`).",
            ephemeral: true,
          });
        }
        try {
          await store.client.mutation("hidden:botCreateGiveaway", {
            guildId: guild.id,
            channelId: interaction.channel.id,
            title: title.slice(0, 100),
            prize: prize.slice(0, 2000),
            winnerCount,
            durationMinutes: minutes,
            dmWinners: true,
            prizeRoleId: prizeRole ? prizeRole.id : undefined,
          });
          store.invalidate(guild.id);
          return interaction.reply({
            content: `🎉 Đã tạo giveaway "${title}" tại ${interaction.channel} — bot gửi embed trong ~30 giây!`,
            ephemeral: true,
          });
        } catch (e) {
          return interaction.reply({ content: `❌ ${e.message}`, ephemeral: true });
        }
      }

      if (sub === "end") {
        const title = interaction.options.getString("title", true);
        const res = await store.client.mutation("hidden:botGiveawayEndNow", {
          guildId: guild.id,
          title,
        });
        store.invalidate(guild.id);
        return interaction.reply({
          content: res.ok
            ? `✅ Đã kết thúc giveaway "${title}" — bot chốt người thắng trong ~30 giây.`
            : `Không tìm thấy giveaway đang chạy tên "${title}".`,
          ephemeral: true,
        });
      }
      return;
    }

    case "setup": {
      if (!canManageGuild(interaction.member)) return needPerm(interaction);
      const sub = interaction.options.getSubcommand();

      if (sub === "log-channel") {
        const channel = interaction.options.getChannel("channel", true);
        await store.client.mutation("bot_writes:botUpdateSettings", {
          guildId: guild.id,
          logChannelId: channel.id,
        });
        store.invalidate(guild.id);
        return interaction.reply({
          content: `✅ Kênh log đã đặt là ${channel}.`,
          ephemeral: true,
        });
      }

      if (sub === "mod-role") {
        const role = interaction.options.getRole("role", true);
        const config = await store.getConfig(guild.id);
        const modRoles = [...new Set([...(config?.modRoles || []), role.id])];
        await store.client.mutation("bot_writes:botUpdateSettings", {
          guildId: guild.id,
          modRoles,
        });
        store.invalidate(guild.id);
        return interaction.reply({
          content: `✅ Role Mod đã thêm ${role}.`,
          ephemeral: true,
        });
      }

      if (sub === "admin-role") {
        const role = interaction.options.getRole("role", true);
        const config = await store.getConfig(guild.id);
        const adminRoles = [...new Set([...(config?.adminRoles || []), role.id])];
        await store.client.mutation("bot_writes:botUpdateSettings", {
          guildId: guild.id,
          adminRoles,
        });
        store.invalidate(guild.id);
        return interaction.reply({
          content: `✅ Role Admin đã thêm ${role}.`,
          ephemeral: true,
        });
      }
      return;
    }

    default:
      return interaction.reply({ content: "Lệnh chưa được hỗ trợ.", ephemeral: true });
  }
};
