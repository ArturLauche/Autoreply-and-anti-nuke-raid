const { Colors, PermissionFlagsBits } = require("discord.js");
const { logEmbed, sendLog } = require("../util");
const { heatSettings, punishMember, choosePunish, heatSummary } = require("../heat");

const MODULE_LABELS = {
  badword: "Từ ngữ xấu",
  invite: "Link mời Discord",
  attachment: "Spam ảnh/file đính kèm",
  mention: "Spam mention",
  malware: "Link độc hại & file nguy hiểm",
};

const INVITE_RE = /(?:discord\.(?:gg|me)\/|discord(?:app)?\.com\/invite\/)[a-zA-Z0-9_-]+/gi;

// Danh sách domain scam/lừa đảo phổ biến (nitro giả, gift giả, crypto scam…)
const MALICIOUS_DOMAINS = [
  "discord-nitro.ru", "discordnitro.ru", "discord-gift.ru", "discordnitro.gift",
  "nitro-gift.ru", "nitrogift.ru", "discordgift.site", "discord-giveaway.com",
  "steam-gift.net", "steamgift.ru", "steam-gifts.com", "steam-giveaways.com",
  "steam-keys.ru", "free-steam-keys.com", "csgo-gifts.ru", "csgofast.com",
  "metamask-verify.com", "metamask-auth.com", "binance-airdrop.top",
  "binance-claim.com", "coinbase-verify.com", "paypal-verify.cc",
  "wallet-connect.verify", "uniswap-airdrop.site", "opensea-verify.com",
  "discord-airdrop.com", "discord-verification.com", "discord-verify.com",
  "discord-login.com", "discord-verify.net", "discordbot.help", "discord-hub.com",
  "nitro-win.ru", "nitrowin.ru", "boost-gift.ru", "nitro-gift.site",
  "get-nitro.com", "freе-nitro.com", "free-nitro.ru", "nitro.quest",
  "discord.gift-claim.com", "claim-gift.ru", "gift-nitro.ru", "nitro-gift.ru",
  "airdrop-token.top", "claim-airdrop.com", "crypto-claim.site",
  "hypesquad-event.com", "xbox-gift.net", "psn-gift.net", "roblox-gift.net",
].map((d) => d.toLowerCase());

const DANGEROUS_EXTENSIONS = [
  ".exe", ".scr", ".bat", ".cmd", ".com", ".msi", ".msp",
  ".vbs", ".vbe", ".js", ".jse", ".hta", ".ps1", ".psm1",
  ".jar", ".apk", ".cpl", ".reg",
];

// Chữ ký nội dung lừa đảo phổ biến
const SCAM_KEYWORD_RE =
  /(free\s?nitro|steam\s?gift|discord\s?nitro\s?(gift|code)|giveaway|airdrop|claim\s?(reward|prize|gift)|you\s?(won|are\s?(the\s?)?winner))/i;

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** So khớp từ với ranh giới từ (không khớp "ass" trong "assassin"). */
function wordBoundaryRegex(word) {
  return new RegExp(`(^|[^\\p{L}\\p{N}])${escapeRegex(word)}([^\\p{L}\\p{N}]|$)`, "iu");
}

function isExempt(member, config) {
  if (!member) return false;
  if (member.id === member.guild.ownerId) return true;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  if ((config?.adminRoles || []).some((id) => member.roles.cache.has(id))) return true;
  if ((config?.modRoles || []).some((id) => member.roles.cache.has(id))) return true;
  // Whitelist toàn cục: role/người dùng được miễn trừ khỏi moderation (và nuke/raid).
  if ((config?.whitelistRoles || []).some((id) => member.roles.cache.has(id))) return true;
  if ((config?.whitelistUsers || []).includes(member.id)) return true;
  return false;
}

/** Tìm link độc hại trong nội dung tin nhắn. */
function findMaliciousLink(content) {
  const urls = content.match(/https?:\/\/[^\s<>"]+|www\.[^\s<>"]+/gi) || [];
  for (const raw of urls) {
    const host = raw
      .replace(/^https?:\/\//i, "")
      .replace(/^www\./i, "")
      .split(/[/?#]/)[0]
      .toLowerCase();
    if (MALICIOUS_DOMAINS.includes(host)) return { kind: "domain", value: host };
    if (/^\d{1,3}(\.\d{1,3}){3}(:\d+)?$/.test(host)) {
      return { kind: "ip", value: host }; // link IP trực tiếp — nghi ngờ
    }
  }
  if (SCAM_KEYWORD_RE.test(content)) return { kind: "scam-keyword", value: "nội dung lừa đảo" };
  return null;
}

/** Tìm file đính kèm có phần mở rộng nguy hiểm. */
function findDangerousAttachment(attachments) {
  for (const att of attachments.values()) {
    const ext = (att.name.match(/\.[a-z0-9]+$/i) || [""])[0].toLowerCase();
    if (DANGEROUS_EXTENSIONS.includes(ext)) return { name: att.name, ext };
  }
  return null;
}

/**
 * Luồng xử lý chung cho mọi vi phạm moderation: cộng nhiệt → chọn hình phạt
 * (tăng cấp theo nhiệt hoặc warn tích lũy) → thực thi → xóa tin → ghi log.
 */
async function punishFlow(client, message, moduleCfg, config, heat, reason, detail, count) {
  const member = message.member;
  if (!member) return;

  const s = heatSettings(config);
  const heatRes = await heat.add(
    message.guild.id,
    message.author.id,
    message.author.username,
    moduleCfg.heat ?? 10,
    s,
  );
  let chosen = choosePunish(moduleCfg.punish || "warn", heatRes);
  let strikeTag = "";
  if (chosen === "warn") {
    const st = heat.strike(message.guild.id, message.author.id, s, message.author.username);
    if (st.escalated) {
      chosen = st.punish;
      strikeTag = ` — đủ ${st.count} warn, tăng cấp ${st.punish}`;
    } else if (st.count > 0 && s.warnStrikeLimit) {
      strikeTag = ` — warn ${st.count}/${s.warnStrikeLimit}`;
    }
  }
  if (chosen !== "warn") heat.markPunished(message.guild.id, message.author.id);
  const action = await punishMember(
    message.guild,
    member,
    chosen,
    reason + strikeTag,
    moduleCfg.timeoutSeconds,
  );

  await message.delete().catch(() => {});

  // Log xóa tin nhắn: ghi rõ bot đã xóa tin gì, của ai, tại kênh nào.
  try {
    const delEmbed = logEmbed({
      title: "🗑️ Bot đã xóa tin nhắn",
      description: `Đã xóa tin nhắn của <@${message.author.id}> tại ${message.channel}.`,
      color: Colors.DarkerGrey,
      fields: [
        { name: "Tác giả", value: `<@${message.author.id}>`, inline: true },
        { name: "Module", value: `\`${moduleCfg.module}\``, inline: true },
        { name: "Nội dung", value: (message.content || "[ảnh/file]").slice(0, 1000) || "…", inline: false },
      ],
      footer: "Protogon · Log xóa tin",
    });
    await sendLog(message.guild, config, delEmbed);
  } catch (e) {
    console.error("[filters:delLog]", e.message);
  }

  try {
    await heat.store.client.mutation("bot_writes:botRecordAntinukeEvent", {
      guildId: message.guild.id,
      module: moduleCfg.module,
      executorId: message.author.id,
      executorName: message.author.username,
      action: action + (heatRes ? ` (nhiệt ${Math.round(heatRes.heat)})` : ""),
      count: count || 1,
      windowSeconds: moduleCfg.windowSeconds || 10,
      threshold: moduleCfg.threshold || 1,
      punish: chosen,
    });
  } catch (e) {
    console.error("[filters:record]", e.message);
  }

  const embed = logEmbed({
    title: `🚨 Cảnh báo: ${MODULE_LABELS[moduleCfg.module] || moduleCfg.module}`,
    description: `${detail} — tin nhắn của <@${message.author.id}> đã bị xóa.`,
    color: Colors.Red,
    fields: [
      { name: "Thủ phạm", value: `<@${message.author.id}>`, inline: true },
      { name: "Xử lý", value: (action + heatSummary(heatRes)).slice(0, 1000), inline: true },
      { name: "Module", value: `\`${moduleCfg.module}\``, inline: true },
    ],
    footer: "Protogon Moderation",
  });
  await sendLog(message.guild, config, embed);
}

/**
 * Quét từng tin nhắn: link mời Discord, từ ngữ xấu, link độc hại, file nguy hiểm,
 * spam mention, spam ảnh/file. Được gọi từ index.js trên sự kiện messageCreate.
 */
async function scanMessage(client, message, store, heat) {
  if (!message.guild || message.author.bot || message.channel.isDMBased?.()) return;
  const config = await store.getConfig(message.guild.id);
  if (!config || config.antinukeEnabled === false) return;
  const member = message.member;
  if (!member || isExempt(member, config)) return;

  const modules = config.modules || [];
  const inviteCfg = modules.find((m) => m.module === "invite");
  const badwordCfg = modules.find((m) => m.module === "badword");
  const malwareCfg = modules.find((m) => m.module === "malware");
  const mentionCfg = modules.find((m) => m.module === "mention");
  const attachmentCfg = modules.find((m) => m.module === "attachment");

  // 1) Link mời Discord
  if (inviteCfg?.enabled && message.content) {
    const match = message.content.match(INVITE_RE);
    if (match) {
      return punishFlow(
        client, message, inviteCfg, config, heat,
        `[Protogon] Chặn link mời Discord: ${match[0]}`,
        `Chứa link mời \`${match[0]}\``,
        1,
      );
    }
  }

  // 2) Từ ngữ xấu
  if (badwordCfg?.enabled && message.content && (config.badWords || []).length > 0) {
    const lower = message.content.toLowerCase();
    const bad = (config.badWords || []).find((w) => w && wordBoundaryRegex(w).test(lower));
    if (bad) {
      return punishFlow(
        client, message, badwordCfg, config, heat,
        `[Protogon] Từ ngữ xấu: "${bad}"`,
        `Chứa từ ngữ xấu \`${bad}\``,
        1,
      );
    }
  }

  // 3) Link độc hại (domain lừa đảo / IP / chữ ký scam)
  if (malwareCfg?.enabled && message.content) {
    const hit = findMaliciousLink(message.content);
    if (hit) {
      return punishFlow(
        client, message, malwareCfg, config, heat,
        `[Protogon] Link độc hại: ${hit.value || hit.kind}`,
        `Chứa link/nội dung độc hại (\`${hit.kind}: ${hit.value || ""}\`)`,
        1,
      );
    }
  }

  // 4) File nguy hiểm (đuôi .exe .scr .bat …)
  if (malwareCfg?.enabled && message.attachments.size > 0) {
    const bad = findDangerousAttachment(message.attachments);
    if (bad) {
      return punishFlow(
        client, message, malwareCfg, config, heat,
        `[Protogon] File nguy hiểm: ${bad.name} (${bad.ext})`,
        `Đính kèm file nguy hiểm \`${bad.name}\` (\`${bad.ext}\`)`,
        1,
      );
    }
  }

  // 5) Spam mention
  if (mentionCfg?.enabled && message.content) {
    const mentions =
      message.mentions.users.size +
      (message.mentions.roles?.size ?? 0) +
      (message.mentions.channels?.size ?? 0) +
      (message.mentions.everyone ? 1 : 0);
    if (mentions > 0) {
      const key = `${message.guild.id}:${message.author.id}`;
      const now = Date.now();
      const arr = mentionBuckets.get(key) ?? [];
      arr.push(now);
      const cutoff = now - (mentionCfg.windowSeconds || 10) * 1000;
      const fresh = arr.filter((t) => t >= cutoff);
      if (fresh.length < (mentionCfg.threshold || 10)) {
        mentionBuckets.set(key, fresh);
        return;
      }
      mentionBuckets.delete(key);
      return punishFlow(
        client, message, mentionCfg, config, heat,
        `[Protogon] Spam mention: ${fresh.length} tin mention trong ${mentionCfg.windowSeconds || 10}s`,
        `<@${message.author.id}> đã gửi **${fresh.length} tin có mention** trong **${mentionCfg.windowSeconds || 10} giây** (ngưỡng ${mentionCfg.threshold || 10})`,
        fresh.length,
      );
    }
  }

  // 6) Spam ảnh / file đính kèm
  if (attachmentCfg?.enabled && message.attachments.size > 0) {
    const key = `${message.guild.id}:${message.author.id}`;
    const now = Date.now();
    const arr = attachmentBuckets.get(key) ?? [];
    arr.push(now);
    const cutoff = now - (attachmentCfg.windowSeconds || 10) * 1000;
    const fresh = arr.filter((t) => t >= cutoff);
    if (fresh.length < (attachmentCfg.threshold || 5)) {
      attachmentBuckets.set(key, fresh);
      return;
    }
    attachmentBuckets.delete(key);
    return punishFlow(
      client, message, attachmentCfg, config, heat,
      `[Protogon] Spam ảnh/file: ${fresh.length} tin đính kèm trong ${attachmentCfg.windowSeconds || 10}s`,
      `<@${message.author.id}> đã gửi **${fresh.length} tin có đính kèm** trong **${attachmentCfg.windowSeconds || 10} giây** (ngưỡng ${attachmentCfg.threshold || 5})`,
      fresh.length,
    );
  }
}

// `${guildId}:${userId}` -> [timestamps của tin có đính kèm]
const attachmentBuckets = new Map();
// `${guildId}:${userId}` -> [timestamps của tin có mention]
const mentionBuckets = new Map();

/** Dọn bucket cũ định kỳ để RAM không tăng mãi (chạy mỗi 5 phút). */
setInterval(() => {
  const now = Date.now();
  const cutoff = now - 600_000; // giữ tối đa 10 phút
  for (const [k, arr] of attachmentBuckets) {
    const fresh = arr.filter((t) => t >= cutoff);
    if (fresh.length === 0) attachmentBuckets.delete(k);
    else attachmentBuckets.set(k, fresh);
  }
  for (const [k, arr] of mentionBuckets) {
    const fresh = arr.filter((t) => t >= cutoff);
    if (fresh.length === 0) mentionBuckets.delete(k);
    else mentionBuckets.set(k, fresh);
  }
}, 300_000);

module.exports = scanMessage;
module.exports.MODULE_LABELS = MODULE_LABELS;
module.exports.findMaliciousLink = findMaliciousLink;
module.exports.findDangerousAttachment = findDangerousAttachment;
