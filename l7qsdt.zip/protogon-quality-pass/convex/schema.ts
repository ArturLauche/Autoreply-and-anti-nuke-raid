import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  users: defineTable({
    discordId: v.string(),
    username: v.string(),
    globalName: v.optional(v.string()),
    avatar: v.optional(v.string()),
    manageableGuildIds: v.array(v.string()),
    lastLoginAt: v.number(),
  }).index("by_discordId", ["discordId"]),

  sessions: defineTable({
    token: v.string(),
    userId: v.id("users"),
    createdAt: v.number(),
    /** Phiên mới phải do OAuth server-side xác thực; undefined = legacy bị từ chối. */
    authVersion: v.optional(v.number()),
  })
    .index("by_token", ["token"])
    .index("by_userId", ["userId"]),

  guilds: defineTable({
    discordId: v.string(),
    name: v.string(),
    icon: v.optional(v.string()),
    memberCount: v.optional(v.number()),
    prefix: v.string(),
    logChannelId: v.optional(v.string()),
    /** Kênh log moderation: auto-mod + lệnh mod thủ công (ban/timeout/kick/warn + ngược lại, purge) kiểu Carl-bot. */
    modLogChannelId: v.optional(v.string()),
    /** Số case moderation đã tăng dần của server (hiển thị "case N" trong log kiểu Carl-bot). */
    modCaseCounter: v.optional(v.number()),
    /** Kênh gửi thông báo sau khi bot trừng phạt thành viên (Moderation). */
    punishNoticeChannelId: v.optional(v.string()),
    /** Mức chi tiết thông báo theo từng hành động ban/timeout/kick/warn. */
    punishNotice: v.optional(
      v.object({
        ban: v.string(),
        timeout: v.string(),
        kick: v.string(),
        warn: v.string(),
      }),
    ),
    /** Backup server: cờ bot cần tạo backup. */
    backupRequested: v.optional(v.boolean()),
    backupPushToGithub: v.optional(v.boolean()),
    /** Backup server: có kèm tin nhắn hay không (tối đa 50 tin/kênh). */
    backupIncludeMessages: v.optional(v.boolean()),
    /** Lỗi backup gần nhất (bot báo lại — dashboard hiển thị thay vì im lặng). */
    backupError: v.optional(v.string()),
    backupErrorAt: v.optional(v.number()),
    /** Khôi phục từ file backup .msc/.json tải lên web (bot nuke khác). */
    importRestoreRequested: v.optional(v.boolean()),
    importFileName: v.optional(v.string()),
    /** File backup tải lên được giữ trong Convex file storage (tối đa 8 MB — chấp nhận cả media). */
    importStorageId: v.optional(v.id("_storage")),
    /** Lỗi xử lý file import gần nhất (bot báo lại — dashboard hiển thị thay vì im lặng). */
    importError: v.optional(v.string()),
    importErrorAt: v.optional(v.number()),
    /** Khóa chống lặp: bot nào claim được thì mới được chạy; lease được gia hạn khi job còn sống. */
    backupClaimedAt: v.optional(v.number()),
    backupLeaseUntil: v.optional(v.number()),
    /** Backup server: cờ bot cần khôi phục + id backup dùng để khôi phục. */
    restoreRequested: v.optional(v.boolean()),
    restoreBackupId: v.optional(v.id("guildBackups")),
    restoreClaimedAt: v.optional(v.number()),
    restoreLeaseUntil: v.optional(v.number()),
    /** Lỗi khôi phục gần nhất (bot báo lại — dashboard hiển thị thay vì im lặng). */
    restoreError: v.optional(v.string()),
    restoreErrorAt: v.optional(v.number()),
    /** Lỗi gửi panel xác minh gần nhất (bot báo lại — dashboard hiển thị). */
    verifyPanelError: v.optional(v.string()),
    verifyPanelErrorAt: v.optional(v.number()),
    /** Lỗi gửi DM trực tiếp gần nhất (bot báo lại — dashboard hiển thị). */
    dmError: v.optional(v.string()),
    dmErrorAt: v.optional(v.number()),
    /** Mốc khôi phục hoàn tất gần nhất — dashboard hiển thị kết quả thay vì người dùng tự đoán. */
    restoreFinishedAt: v.optional(v.number()),
    /**
     * Mốc bot xử lý XONG yêu cầu backup chủ động (lưu xong hoặc bỏ qua vì server
     * không đổi). Dashboard so với thời điểm người dùng bấm "Backup ngay" để báo
     * kết quả — trước đây cờ backupRequested xoá im lặng nên người dùng chỉ thấy
     * "bấm xong không có bản backup nào, cũng không báo gì" (bug thật 23/09).
     */
    backupFinishedAt: v.optional(v.number()),
    /** Yêu cầu backup vừa rồi bị BỎ QUA vì server không đổi (checksum trùng bản gần nhất). */
    backupUnchanged: v.optional(v.boolean()),
    /** Web bật/tắt khôi phục role khi restore (áp dụng cho backup Protogon lẫn file bot nuke). */
    restoreRolesEnabled: v.optional(v.boolean()),
    /** Web bật/tắt khôi phục emoji/sticker khi restore (áp dụng cho backup Protogon lẫn file bot nuke). */
    restoreEmojisEnabled: v.optional(v.boolean()),
    /** Web bật/tắt khôi phục kênh khi restore. */
    restoreChannelsEnabled: v.optional(v.boolean()),
    /** Web bật/tắt khôi phục tin nhắn khi restore. */
    restoreMessagesEnabled: v.optional(v.boolean()),
    /** Tự động backup: số ngày giữa 2 lần (2-30, 0 = tắt). */
    backupAutoDays: v.optional(v.number()),
    /** Lần backup thành công gần nhất (dùng cho lịch tự động). */
    lastBackupAt: v.optional(v.number()),
    /** Raid Intel: bật săn lùng nguồn cơn raid (phân tích cụm tài khoản + audit log). */
    raidHuntEnabled: v.optional(v.boolean()),
    /** Raid Intel: tự ban tài khoản nghi là nguồn cơn raid khi đủ tín hiệu. */
    raidHuntBanSuspects: v.optional(v.boolean()),
    /** Whitelist toàn cục: user/role được miễn trừ khỏi moderation, anti-raid và nuke. */
    whitelistUsers: v.optional(v.array(v.string())),
    whitelistRoles: v.optional(v.array(v.string())),
    modRoles: v.array(v.string()),
    adminRoles: v.array(v.string()),
    antinukeEnabled: v.boolean(),
    managers: v.array(v.string()),
    botInGuild: v.boolean(),
    lastHeartbeat: v.optional(v.number()),
    lockdownEnabled: v.optional(v.boolean()),
    lockdownMinutes: v.optional(v.number()),
    lockdownUntil: v.optional(v.number()),
    lockdownRequested: v.optional(v.boolean()),
    dailyReportEnabled: v.optional(v.boolean()),
    lastReportAt: v.optional(v.number()),
    /** AI Incident Report: bật/tắt cảnh báo khẩn khi raid/nuke được xác nhận. */
    emergencyAlertEnabled: v.optional(v.boolean()),
    /** AI Incident Report: cảnh báo khẩn có ping @everyone không. */
    logPingEveryone: v.optional(v.boolean()),
    /** Welcome/Goodbye: chào thành viên mới + tạm biệt thành viên rời server. */
    welcomeEnabled: v.optional(v.boolean()),
    welcomeChannelId: v.optional(v.string()),
    welcomeMessage: v.optional(v.string()),
    welcomeUseEmbed: v.optional(v.boolean()),
    goodbyeEnabled: v.optional(v.boolean()),
    goodbyeChannelId: v.optional(v.string()),
    goodbyeMessage: v.optional(v.string()),
    goodbyeUseEmbed: v.optional(v.boolean()),
    /**
     * Welcome/Goodbye v2 (học Carl-bot/Welcomer/ProBot): template ngẫu nhiên
     * (1 dòng = 1 câu, bot chọn ngẫu nhiên mỗi lượt join/leave), welcome DM,
     * embed tùy chỉnh (tiêu đề/màu/ảnh banner/thumbnail), autorole.
     */
    welcomeRandom: v.optional(v.string()),
    goodbyeRandom: v.optional(v.string()),
    welcomeDmEnabled: v.optional(v.boolean()),
    welcomeDmMessage: v.optional(v.string()),
    welcomeEmbedTitle: v.optional(v.string()),
    welcomeEmbedColor: v.optional(v.string()),
    welcomeEmbedImage: v.optional(v.string()),
    welcomeEmbedThumbnail: v.optional(v.string()),
    goodbyeEmbedTitle: v.optional(v.string()),
    goodbyeEmbedColor: v.optional(v.string()),
    goodbyeEmbedImage: v.optional(v.string()),
    goodbyeEmbedThumbnail: v.optional(v.string()),
    autoroleEnabled: v.optional(v.boolean()),
    autoroleRoleId: v.optional(v.string()),
    autoroleDelaySec: v.optional(v.number()),
    autoroleIncludeBots: v.optional(v.boolean()),
    /**
     * THẺ ẢNH (v3): bot tự vẽ PNG riêng cho từng thành viên (nền dưới đây +
     * avatar + tên) rồi gửi kèm embed. Chỉ áp dụng khi `welcome/goodbyeUseEmbed`
     * bật — ảnh cần embed mới có chỗ hiển thị. Màu nhấn dùng chung
     * `welcome/goodbyeEmbedColor` (không thêm cột màu trùng nghĩa).
     */
    welcomeCardEnabled: v.optional(v.boolean()),
    welcomeCardBackground: v.optional(v.string()),
    goodbyeCardEnabled: v.optional(v.boolean()),
    goodbyeCardBackground: v.optional(v.string()),
    badWords: v.optional(v.array(v.string())),
    heatEnabled: v.optional(v.boolean()),
    heatDecayPerMin: v.optional(v.number()),
    heatWarnAt: v.optional(v.number()),
    heatTimeoutAt: v.optional(v.number()),
    heatKickAt: v.optional(v.number()),
    heatBanAt: v.optional(v.number()),
    heatResetRequested: v.optional(v.boolean()),
    heatResetUserId: v.optional(v.string()),
    joinGateEnabled: v.optional(v.boolean()),
    joinGateMinAgeDays: v.optional(v.number()),
    joinGateRequireAvatar: v.optional(v.boolean()),
    joinGateRequireFlag: v.optional(v.boolean()),
    joinGateRaidKick: v.optional(v.boolean()),
    joinGatePunish: v.optional(v.union(v.literal("kick"), v.literal("ban"))),
    joinGateWhitelist: v.optional(v.array(v.string())),
    heatRepeatMultiplier: v.optional(v.number()),
    heatRepeatWindowMin: v.optional(v.number()),
    warnStrikeLimit: v.optional(v.number()),
    warnStrikeWindowMin: v.optional(v.number()),
    warnStrikePunish: v.optional(
      v.union(v.literal("timeout"), v.literal("kick"), v.literal("ban")),
    ),
    /** Trần tổng punish tự động/phút/guild (actionBudget) — 0/undefined = mặc định 20. */
    actionBudgetPerMinute: v.optional(v.number()),
    /**
     * Threat relay — chia sẻ chữ ký raid GIỮA CÁC SERVER dùng chung bot (opt-in).
     * Khi server A bị raid, pattern (nội dung spam/tên bot nuke/invite) được bắn
     * lên relay (ẩn danh, không kèm userId) — server B có relayShare=true sẽ tải
     * về và chặn sớm hơn. TẤT CẢ mặc định TẮT: không server nào nhận dữ liệu từ
     * server khác nếu chủ server không bật.
     */
    relayShare: v.optional(v.boolean()),
    relayReceive: v.optional(v.boolean()),
    /** DI SẢN: hash mật khẩu tính năng ẩn theo từng server (salt = guildId). Mật
     *  khẩu giờ nằm toàn cục ở botStatus; field này chỉ được đọc để nâng cấp một
     *  lần rồi xoá — đừng ghi mới vào đây. */
    hiddenPasswordHash: v.optional(v.string()),
    /** DI SẢN: bộ đếm chống dò theo server (giờ đếm toàn cục ở botStatus). */
    hiddenVerifyLastAt: v.optional(v.number()),
    hiddenVerifyFails: v.optional(v.number()),
    /** Chủ đề màu riêng cho web của server (key trong SERVER_THEMES). */
    theme: v.optional(v.string()),
    dmTargetUserId: v.optional(v.string()),
    dmTargetUsername: v.optional(v.string()),
    dmMessage: v.optional(v.string()),
    dmRequested: v.optional(v.boolean()),
    /** Verify system: bật xác minh thành viên khi vào server. */
    verifyEnabled: v.optional(v.boolean()),
    /** Phương thức xác minh: "button" (bấm nút) hoặc "captcha" (nhập mã DM). */
    verifyMethod: v.optional(v.union(v.literal("button"), v.literal("captcha"))),
    verifyChannelId: v.optional(v.string()),
    unverifiedRoleId: v.optional(v.string()),
    verifiedRoleId: v.optional(v.string()),
    /** Verify welcome DM: gửi embed chào mừng qua DM sau khi verify thành công. */
    verifyWelcomeEnabled: v.optional(v.boolean()),
    verifyWelcomeTitle: v.optional(v.string()),
    verifyWelcomeDescription: v.optional(v.string()),
    verifyWelcomeColor: v.optional(v.string()),
    verifySendPanel: v.optional(v.boolean()),
    /** Alt account + VPN detection system. */
    altDetectionEnabled: v.optional(v.boolean()),
    vpnBlockEnabled: v.optional(v.boolean()),
    /** Tuổi tối thiểu (ngày) khi xét alt — tài khoản dưới ngưỡng này bị tăng riskScore. */
    altMinAgeDays: v.optional(v.number()),
    /** Ngưỡng riskScore tối đa được chấp nhận (vượt thì bị kick/ban). */
    altMaxRiskScore: v.optional(v.number()),
    /** Hình phạt cho alt account: kick | ban | timeout | verify (gán lại unverified role). */
    altPunish: v.optional(
      v.union(v.literal("kick"), v.literal("ban"), v.literal("timeout"), v.literal("verify")),
    ),
    /** Timeout duration (phút) khi altPunish = timeout. */
    altTimeoutMinutes: v.optional(v.number()),
    /** Roles được miễn khỏi alt detection. */
    altWhitelistRoles: v.optional(v.array(v.string())),
    /** Users được miễn khỏi alt detection. */
    altWhitelistUsers: v.optional(v.array(v.string())),
    /** Phân tích tương đồng username: ngưỡng similarity (0-100) để link accounts. */
    altSimilarityThreshold: v.optional(v.number()),
    /** Thời gian cửa sổ (phút) — 2 account join trong khoảng này + similarity cao = alt suspects. */
    altJoinWindowMinutes: v.optional(v.number()),
    /** Chế độ kiểm tra VPN: strict (block) | warn (log only) | off. */
    altVpnMode: v.optional(v.union(v.literal("strict"), v.literal("warn"), v.literal("off"))),
    /** Chế độ an toàn: chỉ phạt khi có >= 2 bằng chứng độc lập (chống chặn nhầm). */
    altSafeMode: v.optional(v.boolean()),
    /**
     * Mốc LẦN CUỐI dashboard ghi cấu hình (updateSettings). Khác `updatedAt` —
     * `updatedAt` bị chính bot bump mỗi lượt sync/heartbeat nên không dùng làm tín
     * hiệu "cấu hình vừa đổi" được. Vòng tick của bot đọc field này để xoá cache
     * config của đúng guild vừa sửa: không có nó thì thay đổi từ dashboard phải
     * chờ hết TTL cache (30 phút) mới tới bot, trong khi giao diện hứa "khoảng 3
     * phút" — người dùng tưởng tính năng hỏng (bug thật 23/09, welcome/goodbye).
     */
    settingsChangedAt: v.optional(v.number()),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_discordId", ["discordId"])
    .index("by_botInGuild", ["botInGuild"]),

  reactionRolePanels: defineTable({
    guildId: v.string(),
    channelId: v.string(),
    label: v.string(),
    /** Nội dung / mô tả hiển thị trong embed (mặc định nếu bỏ trống). */
    description: v.optional(v.string()),
    /** Ảnh thumbnail hiển thị góc phải embed. */
    thumbnailUrl: v.optional(v.string()),
    entries: v.array(v.object({ emoji: v.string(), roleId: v.string() })),
    messageId: v.optional(v.string()),
    /** Lỗi gửi panel gần nhất (bot báo lại — web hiển thị thay vì im lặng). */
    postError: v.optional(v.string()),
    postErrorAt: v.optional(v.number()),
    enabled: v.boolean(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_guildId", ["guildId"])
    .index("by_guildId_posted", ["guildId", "messageId"]),

  giveaways: defineTable({
    guildId: v.string(),
    channelId: v.string(),
    title: v.string(),
    prize: v.string(),
    winnerCount: v.number(),
    durationMinutes: v.number(),
    endsAt: v.number(),
    dmWinners: v.boolean(),
    requiredRoleId: v.optional(v.string()),
    /** Role tự cấp cho người thắng khi giveaway kết thúc. */
    prizeRoleId: v.optional(v.string()),
    /** Mẫu tin nhắn: default | luxury | vip | simple. */
    template: v.optional(v.string()),
    /** Lời dẫn / nội dung tùy chỉnh thay cho mẫu. */
    message: v.optional(v.string()),
    /** Ảnh nền chèn vào embed. */
    imageUrl: v.optional(v.string()),
    /** Lời chúc mừng tùy chỉnh khi kết thúc. */
    endMessage: v.optional(v.string()),
    status: v.union(v.literal("active"), v.literal("ended"), v.literal("cancelled")),
    messageId: v.optional(v.string()),
    /** Lỗi gửi/kết thúc giveaway gần nhất (bot báo lại — web hiển thị thay vì im lặng). */
    postError: v.optional(v.string()),
    postErrorAt: v.optional(v.number()),
    endError: v.optional(v.string()),
    endErrorAt: v.optional(v.number()),
    entries: v.array(v.object({ userId: v.string(), username: v.string() })),
    winners: v.array(v.object({ userId: v.string(), username: v.string() })),
    createdAt: v.number(),
  })
    .index("by_guildId", ["guildId"])
    .index("by_guildId_endsAt", ["guildId", "endsAt"]),

  autoReplies: defineTable({
    guildId: v.string(),
    name: v.string(),
    triggerType: v.union(v.literal("keyword"), v.literal("mention")),
    keywords: v.array(v.string()),
    response: v.string(),
    channels: v.array(v.string()),
    cooldownSeconds: v.number(),
    enabled: v.boolean(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_guildId", ["guildId"])
    .index("by_guildId_name", ["guildId", "name"]),

  antinukeModules: defineTable({
    guildId: v.string(),
    module: v.string(),
    enabled: v.boolean(),
    threshold: v.number(),
    windowSeconds: v.number(),
    punish: v.union(v.literal("warn"), v.literal("kick"), v.literal("ban"), v.literal("timeout")),
    /** Hành động kết hợp: warn/kick/ban/timeout + deleteMessages/purgeMessages. */
    actions: v.optional(v.array(v.string())),
    timeoutSeconds: v.optional(v.number()),
    whitelistRoles: v.array(v.string()),
    heat: v.optional(v.number()),
    updatedAt: v.number(),
  })
    .index("by_guildId", ["guildId"])
    .index("by_guild_module", ["guildId", "module"]),

  heatStates: defineTable({
    guildId: v.string(),
    userId: v.string(),
    username: v.string(),
    heat: v.number(),
    updatedAt: v.number(),
    warnStrikes: v.optional(v.number()),
  })
    .index("by_guildId", ["guildId"])
    .index("by_guildId_userId", ["guildId", "userId"])
    .index("by_guildId_heat", ["guildId", "heat"]),

  guildChannels: defineTable({
    guildId: v.string(),
    channelId: v.string(),
    name: v.string(),
    type: v.number(),
  })
    .index("by_guildId", ["guildId"])
    .index("by_guildId_channelId", ["guildId", "channelId"]),

  guildRoles: defineTable({
    guildId: v.string(),
    roleId: v.string(),
    name: v.string(),
    color: v.number(),
    position: v.number(),
  })
    .index("by_guildId", ["guildId"])
    .index("by_guildId_roleId", ["guildId", "roleId"]),

  /**
   * Emoji tuỳ chỉnh của server (bot đồng bộ định kỳ) — dashboard hiển thị picker
   * để chèn thẳng `<:ten:id>` / `<a:ten:id>` vào tin nhắn welcome/goodbye.
   * Chỉ là bản sao để hiển thị: bot luôn gửi MÃ emoji, không phải ảnh, nên emoji
   * xoá sau đó chỉ khiến tin nhắn hiện `:ten:` — không vỡ gì.
   */
  guildEmojis: defineTable({
    guildId: v.string(),
    emojiId: v.string(),
    name: v.string(),
    animated: v.boolean(),
  })
    .index("by_guildId", ["guildId"])
    .index("by_guildId_emojiId", ["guildId", "emojiId"]),

  modActions: defineTable({
    guildId: v.string(),
    action: v.string(),
    targetId: v.optional(v.string()),
    targetName: v.optional(v.string()),
    executorId: v.optional(v.string()),
    executorName: v.optional(v.string()),
    reason: v.optional(v.string()),
    details: v.optional(v.string()),
    /** Số case tăng dần của server (kiểu Carl-bot). */
    caseNumber: v.optional(v.number()),
    createdAt: v.number(),
  })
    .index("by_guildId", ["guildId"])
    .index("by_guildId_createdAt", ["guildId", "createdAt"]),

  guildBackups: defineTable({
    guildId: v.string(),
    guildName: v.string(),
    /** JSON cấu trúc server: roles (tên/màu/quyền) + channels (kênh/quyền kênh) + tin nhắn. */
    backupJson: v.string(),
    roleCount: v.number(),
    channelCount: v.number(),
    /** Số emoji đã backup (khôi phục lại được khi restore). */
    emojiCount: v.optional(v.number()),
    /** Số sticker đã backup (khôi phục lại được khi restore). */
    stickerCount: v.optional(v.number()),
    /** Số tin nhắn đã backup (0 = không kèm tin). */
    messageCount: v.optional(v.number()),
    /** Nguồn backup: "backup" (bot tự chụp) | "import" (tải file .msc/.json lên) | "clone" (sao chép từ server khác). */
    source: v.optional(v.string()),
    /** SHA-256 checksum của backup JSON (dùng cho incremental backup + xác minh). */
    backupChecksum: v.optional(v.string()),
    /** Checksum "ổn định" của snapshot (không gồm timestamps/media) — so khớp incremental để bỏ qua backup không đổi. */
    backupSnapshotChecksum: v.optional(v.string()),
    /** Có nén zlib không (true = compressed JSON). */
    backupCompressed: v.optional(v.boolean()),
    /** Có mã hóa AES-256-GCM không. */
    backupEncrypted: v.optional(v.boolean()),
    /** ID backup trước đó (dùng cho diff). */
    previousBackupId: v.optional(v.string()),
    /** URL gist GitHub nếu backup đã được đẩy lên đám mây. */
    githubUrl: v.optional(v.string()),
    pushedToGithub: v.boolean(),
    createdAt: v.number(),
  })
    .index("by_guildId", ["guildId"])
    .index("by_guildId_createdAt", ["guildId", "createdAt"]),

  antinukeEvents: defineTable({
    guildId: v.string(),
    module: v.string(),
    executorId: v.optional(v.string()),
    executorName: v.optional(v.string()),
    executorNameLower: v.optional(v.string()),
    action: v.string(),
    count: v.number(),
    windowSeconds: v.number(),
    threshold: v.number(),
    punish: v.string(),
    createdAt: v.number(),
  })
    .index("by_guildId", ["guildId"])
    .index("by_guildId_createdAt", ["guildId", "createdAt"])
    .index("by_createdAt", ["createdAt"]),

  /**
   * Raid Intel — dữ liệu huấn luyện bot + AI: mỗi vụ raid/nuke được xử lý
   * ghi lại một mẫu có cấu trúc (module, ngưỡng, cụm tài khoản, AI verdict,
   * kết quả săn nguồn cơn raid). Bot dùng để tự học nhận diện biến thể mới.
   */
  /**
   * Threat Relay — chữ ký raid chia sẻ GIỮA CÁC SERVER (opt-in, ẩn danh).
   * Xem convex/relay.ts — TTL 24h, rate-limit 10/guild nguồn/phút, weight chống
   * đầu độc, KHÔNG lưu guildId gốc (chỉ hash 1 chiều).
   */
  relaySignatures: defineTable({
    /** Loại: spam-text | bot-name | invite-code | app-name. */
    kind: v.string(),
    /** Nội dung đã chuẩn hóa (≤60 ký tự, không mention/điều khiển). */
    value: v.string(),
    /** Số lần thấy (tăng khi dedupe) — ≥2 = ít nhất 2 nguồn cùng xác nhận. */
    weight: v.optional(v.number()),
    /** Hash 1 chiều của guild nguồn (không truy ngược được). */
    sourceHash: v.string(),
    sourceHashes: v.optional(v.array(v.string())),
    createdAt: v.number(),
    lastSeenAt: v.number(),
  })
    .index("by_kind_value", ["kind", "value"])
    .index("by_source_createdAt", ["sourceHash", "createdAt"])
    // Dùng cho lọc TTL (relayStatus / botGetRelaySignatures / botCleanupRelay đều
    // chỉ cần signature còn hạn theo createdAt) — trước đây 3 đường này full scan
    // toàn bảng, bảng càng đông server (mỗi nguồn ≤10 signature/phút) càng đắt.
    .index("by_createdAt", ["createdAt"]),

  raidSamples: defineTable({
    guildId: v.string(),
    guildName: v.optional(v.string()),
    /** Module chính kích hoạt (massJoin, massBan, spam…). */
    module: v.string(),
    count: v.number(),
    windowSeconds: v.number(),
    threshold: v.number(),
    action: v.optional(v.string()),
    punish: v.optional(v.string()),
    /** AI Guard: classification (raid/individual/benign) + độ tin cậy + lý do. */
    aiClassification: v.optional(v.string()),
    aiConfidence: v.optional(v.number()),
    aiReason: v.optional(v.string()),
    lockdownTriggered: v.optional(v.boolean()),
    punishedCount: v.optional(v.number()),
    /** Hồ sơ cụm tài khoản trong vụ raid (dùng để huấn luyện nhận diện nguồn cơn). */
    clusterMemberCount: v.optional(v.number()),
    clusterAvgAccountAgeDays: v.optional(v.number()),
    clusterSharedAvatarCount: v.optional(v.number()),
    clusterJoinBurstSeconds: v.optional(v.number()),
    /** External App Guard: danh sách app được kết nối trong vụ (tên app + người kết nối). */
    apps: v.optional(
      v.array(
        v.object({
          appName: v.optional(v.string()),
          executorName: v.optional(v.string()),
          executorId: v.optional(v.string()),
        }),
      ),
    ),
    /** External App Guard: người dùng đã bị xử lý trong vụ (ban/kick/warn…). */
    punished: v.optional(
      v.array(
        v.object({
          userId: v.optional(v.string()),
          username: v.optional(v.string()),
          action: v.optional(v.string()),
        }),
      ),
    ),
    /** Kết quả săn lùng nguồn cơn raid. */
    sourceHunt: v.optional(
      v.object({
        suspectedSourceId: v.optional(v.string()),
        suspectedSourceName: v.optional(v.string()),
        reason: v.string(),
        banned: v.boolean(),
        confidence: v.number(),
      }),
    ),
    createdAt: v.number(),
  })
    .index("by_guildId", ["guildId"])
    .index("by_guildId_createdAt", ["guildId", "createdAt"])
    .index("by_createdAt", ["createdAt"]),

  botStatus: defineTable({
    kind: v.literal("status"),
    online: v.boolean(),
    guildCount: v.number(),
    memberCount: v.number(),
    lastHeartbeat: v.number(),
    startedAt: v.number(),
    version: v.string(),
    /** Discord ID của admin sở hữu bot (người duy nhất được phép mở khóa tính năng ẩn). */
    ownerDiscordId: v.optional(v.string()),
    /** Avatar bot hiển thị trên web (logo, quản lý…). */
    botAvatarUrl: v.optional(v.string()),
    /** Avatar trợ lý AI Haimiya-senpai hiển thị trên web. */
    haimiyaAvatarUrl: v.optional(v.string()),
    /** Mật khẩu mở khóa TÍNH NĂNG ẨN — TOÀN CỤC (một mật khẩu cho mọi server),
     *  salt không kèm guildId: cổng phải giống nhau ở mọi dashboard, không chỉ
     *  ở server nơi chủ bot đặt mật khẩu. */
    hiddenPasswordHash: v.optional(v.string()),
    /** Chống dò mật khẩu ẩn — bộ đếm toàn cục (5 lần sai / 10 phút). */
    hiddenVerifyFails: v.optional(v.number()),
    hiddenVerifyLastAt: v.optional(v.number()),
    /** Tên chủ bot (bot tự lấy từ Discord mỗi lần sync — cập nhật 24/7). */
    ownerName: v.optional(v.string()),
    /** Avatar chủ bot (bot tự lấy từ Discord mỗi lần sync — cập nhật 24/7). */
    ownerAvatarUrl: v.optional(v.string()),
    /**
     * Khả năng VẼ THẺ ảnh chào của máy chủ bot (v3): thư viện canvas + font nhúng.
     * Bot báo 1 lần lúc khởi động qua `status:reportCardCapability`.
     * `undefined` = bot chưa báo (bản cũ) — dashboard KHÔNG được coi là hỏng.
     */
    cardReady: v.optional(v.boolean()),
    cardUnavailableReason: v.optional(v.string()),
    /** Threat Intel: bật hệ thống tự nghiên cứu raid/nuke từ nguồn mở (owner bật/tắt). */
    threatResearchEnabled: v.optional(v.boolean()),
    /** Threat Intel: cho phép AI tổng hợp MỖI TUẦN 1 lần (~8-15k tokens/tháng) hay không. */
    threatResearchAiWeekly: v.optional(v.boolean()),
    /** Threat Intel: thời điểm chạy nghiên cứu gần nhất + lần kế tiếp (ms epoch). */
    threatResearchLastRunAt: v.optional(v.number()),
    threatResearchNextRunAt: v.optional(v.number()),
    /** Threat Intel: tổng số lượt chạy nghiên cứu. */
    threatResearchRuns: v.optional(v.number()),
    /** Threat Intel: nguồn đã tải ở lượt gần nhất (tên nguồn, tối đa 8). */
    threatResearchLastSources: v.optional(v.array(v.string())),
    /** Threat Intel: tóm tắt AI gần nhất (lý do học được gì — hiển thị web Admin). */
    threatResearchLastSummary: v.optional(v.string()),
    /** Threat Intel: lượt gần nhất có dùng AI hay chỉ heuristics (0 token). */
    threatResearchLastAiUsed: v.optional(v.boolean()),
    /** Threat Intel: từ khóa scam MỚI học được (hợp nhất vào wildcard regex — miễn phí dùng vĩnh viễn). */
    threatKeywords: v.optional(v.array(v.string())),
    /** Threat Intel: cụm từ scam nhiều từ học được (vd "free gift redeem"). */
    threatScamPhrases: v.optional(v.array(v.string())),
    /** Tiến độ học của lượt gần nhất: số từ khóa/cụm từ mới + nguồn tải được. */
    threatResearchLastNewKeywords: v.optional(v.number()),
    threatResearchLastNewPhrases: v.optional(v.number()),
    threatResearchLastSourceCount: v.optional(v.number()),
    /** Lỗi lượt nghiên cứu gần nhất (bot báo lại — Admin hiển thị thay vì im lặng). */
    threatResearchLastError: v.optional(v.string()),
    threatResearchLastErrorAt: v.optional(v.number()),
    /** Học thủ công: cờ yêu cầu (/research learn hoặc nút web) + thời điểm + người yêu cầu. */
    threatManualLearnRequested: v.optional(v.boolean()),
    threatManualLearnAt: v.optional(v.number()),
    threatManualLearnBy: v.optional(v.string()),
    /** Self-Diagnose: bot tự chẩn đoán lỗi runtime qua AI (Mimo/Kira) + đăng đề xuất vá vào kênh log. Owner bật/tắt trên Admin web. */
    // Threat Intel: bật/tắt GỬI THÔNG BÁO học tập vào kênh log các server.
    researchNotifyEnabled: v.optional(v.boolean()),
    // Threat Intel mở rộng: digest tuần + AI review từ khóa + thống kê engine cục bộ.
    threatDigestLast: v.optional(v.string()),
    threatDigestLastAt: v.optional(v.number()),
    threatKeywordReviewSuspects: v.optional(
      v.array(v.object({ keyword: v.string(), benignHits: v.number() })),
    ),
    threatKeywordReviewAt: v.optional(v.number()),
    threatAiReviewRequested: v.optional(v.boolean()),
    threatUrlhausDomains: v.optional(v.number()),
    threatNgramClusters: v.optional(v.number()),
    selfDiagnoseEnabled: v.optional(v.boolean()),
    /** Self-Diagnose: thời điểm chẩn đoán gần nhất (để hiển thị trên web + chống lặp). */
    selfDiagnoseLastAt: v.optional(v.number()),
    selfDiagnoseLastFingerprint: v.optional(v.string()),
    selfDiagnoseLastSeverity: v.optional(
      v.union(v.literal("high"), v.literal("medium"), v.literal("low")),
    ),
    selfDiagnoseLastSummary: v.optional(v.string()),
    /** Self-Diagnose: số lượt chẩn đoán đã chạy (hiển thị thống kê trên web). */
    selfDiagnoseRuns: v.optional(v.number()),
    /** Chìa khóa bot (botAuth): SHA-256("protogon-bot-key::" + OWNER_SEED) — chủ bot đặt 1 lần qua Admin web. Khi có giá trị, mọi function bot-side yêu cầu botKey khớp. */
    botKeySeed: v.optional(v.string()),
    /** Lần bootstrap (tự cấp phát botKey) thành công gần nhất — chống xoay key dồn dập. */
    lastBootstrapAt: v.optional(v.number()),
    /** Lần bot gọi bootstrap gần nhất (kể cả thất bại) — chống dùng action làm relay spam Discord API. */
    lastBootstrapAttemptAt: v.optional(v.number()),
    /** Application ID của bot thật (xác minh qua Discord API lúc bootstrap). */
    botApplicationId: v.optional(v.string()),
    /** Seed cho chìa khóa chức năng (botFunc): các action nguy hiểm (OAuth exchange, AI chat) yêu cầu funcKey. */
    funcSeed: v.optional(v.string()),
    /** Sức khỏe AI (đợt 12): tổng hợp từ aiStats() của bot — gộp vào vòng sync 60s sẵn có (0 function call thêm). Chỉ owner xem qua Admin. */
    aiHealth: v.optional(
      v.object({
        available: v.boolean(),
        providers: v.array(
          v.object({
            label: v.string(),
            model: v.optional(v.string()),
            inCooldown: v.boolean(),
          }),
        ),
        verdictCacheSize: v.number(),
        callsLastMinute: v.number(),
        inFlight: v.number(),
        verdictsLastHour: v.object({
          raid: v.number(),
          individual: v.number(),
          benign: v.number(),
          offline: v.number(),
          cache: v.number(),
        }),
        misfire: v.object({
          misfires7d: v.number(),
          pending: v.number(),
        }),
        reportedAt: v.number(),
      }),
    ),
  }).index("by_kind", ["kind"]),

  /** Audit log — ghi lại mọi thay đổi settings trên web. */
  auditLog: defineTable({
    guildId: v.string(),
    executorId: v.string(),
    executorName: v.optional(v.string()),
    action: v.string(),
    field: v.string(),
    oldValue: v.optional(v.string()),
    newValue: v.optional(v.string()),
    createdAt: v.number(),
  })
    .index("by_guildId", ["guildId"])
    .index("by_guildId_createdAt", ["guildId", "createdAt"]),

  /**
   * Webhook tùy chỉnh do bot tạo theo yêu cầu (log qua webhook): người dùng
   * chọn kênh, tên (kèm emoji động/tĩnh), avatar, màu embed, nội dung kèm và
   * loại sự kiện log. Bot thực hiện tạo/sửa/xóa trên Discord rồi báo lại.
   */
  guildWebhooks: defineTable({
    guildId: v.string(),
    /** Tên webhook (1-80 ký tự) — hỗ trợ emoji tĩnh lẫn động (<a:name:id>). */
    name: v.string(),
    channelId: v.string(),
    /** URL ảnh đại diện webhook (https). */
    avatarUrl: v.optional(v.string()),
    /** Màu embed ghi đè khi gửi log qua webhook (số 0-16777215). */
    color: v.optional(v.number()),
    /** Nội dung gửi kèm trước embed — placeholder {server} {time} {action}. */
    contentTemplate: v.optional(v.string()),
    /** Loại sự kiện nhận: "mod" (case log ban/kick/timeout/warn/purge…) | "general" (anti nuke/raid + log chung). */
    eventTypes: v.array(v.string()),
    enabled: v.boolean(),
    /** pending_create → ready → pending_update/pending_delete/error (bot xử lý). */
    status: v.union(
      v.literal("pending_create"),
      v.literal("ready"),
      v.literal("pending_update"),
      v.literal("pending_delete"),
      v.literal("error"),
    ),
    /** Web bấm "Gửi thử" → bot gửi 1 embed test rồi xóa cờ. */
    testRequested: v.optional(v.boolean()),
    /** Webhook MẶC ĐỊNH của bot (tự tạo khi set kênh log, nhận mọi log chưa có webhook tùy chỉnh khớp). */
    isDefault: v.optional(v.boolean()),
    webhookId: v.optional(v.string()),
    token: v.optional(v.string()),
    lastError: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.number(),
  }).index("by_guildId", ["guildId"]),

  /** Member join records for alt detection — lưu lịch sử join + risk analysis. */
  memberJoins: defineTable({
    guildId: v.string(),
    userId: v.string(),
    username: v.string(),
    avatar: v.optional(v.string()),
    /** Discord account creation timestamp. */
    createdAt: v.number(),
    /** Discord public flags (USER_FLAGS). */
    flags: v.optional(v.number()),
    /** Thời gian bot ghi nhận join vào server. */
    joinedAt: v.number(),
    /** Điểm rủi ro tổng hợp (0-100). */
    riskScore: v.number(),
    /** Danh sách yếu tố rủi ro chi tiết. */
    riskFactors: v.array(v.string()),
    /** Số nhóm bằng chứng độc lập (0-7) — quyết định mức phạt, chống chặn nhầm. */
    strongSignals: v.optional(v.number()),
    /** IP có phải VPN/Proxy không. */
    isVPN: v.optional(v.boolean()),
    /** Quốc gia từ IP (nếu detect được). */
    ipCountry: v.optional(v.string()),
    /** Tổ chức/TISP từ IP. */
    ipOrg: v.optional(v.string()),
    /** Kết quả xử lý: kick/ban/timeout/verify/pass/warn. */
    action: v.optional(v.string()),
    /** Lý do xử lý chi tiết. */
    actionReason: v.optional(v.string()),
    /** ID account bị nghi là alt (nếu link được). */
    linkedUserId: v.optional(v.string()),
    /** Điểm tương đồng với account đã link (0-100). */
    similarityScore: v.optional(v.number()),
    /** Lần cập nhật cuối (vd: đánh dấu đã bị phạt). */
    updatedAt: v.optional(v.number()),
  })
    .index("by_guildId", ["guildId"])
    .index("by_guildId_joinedAt", ["guildId", "joinedAt"])
    .index("by_guildId_riskScore", ["guildId", "riskScore"]),

  /**
   * researchRuns — lịch sử học tập của bot (Threat Intel). 1 row = 1 lượt nghiên
   * cứu (tự động mỗi 4h HOẶC thủ công từ lệnh /research learn / web Admin).
   * Giữ tối đa ~50 row mới nhất (mutation tự dọn cũ) — bảng luôn nhỏ, reads rẻ.
   */
  researchRuns: defineTable({
    /** "auto" (định kỳ 4h) | "manual" (/research learn hoặc nút web). */
    trigger: v.string(),
    /** Nguồn đã tải thành công (reddit-*, cisa-kev, raid-incidents…). */
    sources: v.array(v.string()),
    /** Số từ khóa / cụm từ MỚI học được trong lượt này. */
    newKeywords: v.number(),
    newPhrases: v.number(),
    /** AI có tổng hợp trong lượt này không (tốn token Kira/Mimo). */
    aiUsed: v.boolean(),
    /** Tóm tắt xu hướng AI (nếu có). */
    summary: v.optional(v.string()),
    /** Tổng số từ khóa bot đang nhớ sau lượt này (tiến độ ghi nhớ). */
    totalKeywords: v.number(),
    totalPhrases: v.number(),
    /** Số từ khóa học từ raid thật (ambient learning). */
    learnedFromIncidents: v.optional(v.number()),
    /** Người yêu cầu học thủ công (username Discord) — null khi tự động. */
    requestedBy: v.optional(v.string()),
    createdAt: v.number(),
  }).index("by_createdAt", ["createdAt"]),
});
