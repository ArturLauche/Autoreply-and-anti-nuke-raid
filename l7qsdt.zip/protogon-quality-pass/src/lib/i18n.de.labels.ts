/**
 * src/lib/i18n.de.labels.ts — Bản dịch DE cho NHÃN & DỮ LIỆU HIỂN THỊ,
 * song song với src/lib/i18n.en.labels.ts (nhãn hằng số dữ liệu render động
 * qua translate(item.label), mảnh câu ghép, toast dựng trong callback).
 */
export const DE_LABELS: Record<string, string> = {
  "(tất cả)": "(alle)",
  "1 giờ": "1 Stunde",
  "24 module": "24 Module",
  "3 ngày": "3 Tage",
  "30 phút": "30 Minuten",
  "5 phút": "5 Minuten",
  "7 ngày": "7 Tage",
  "< 500 thành viên": "unter 500 Mitgliedern",
  "AI phân biệt raid hay cá nhân": "KI unterscheidet Raids von Einzeltätern",
  "Avatar trợ lý AI (Haimiya-senpai)": "KI-Assistent-Avatar (Haimiya-senpai)",
  "Backup & khôi phục server": "Server-Backup & -Wiederherstellung",
  "Backup (kèm tin nhắn) sẽ được lưu trên Convex.":
    "Das Backup (mit Nachrichten) wird in Convex gespeichert.",
  "Backup sẽ được lưu trên Convex.": "Das Backup wird in Convex gespeichert.",
  "Ban hàng loạt": "Massen-Ban",
  "Bot Discord tự trả lời & chống nuke/raid": "Discord-Bot: Auto-Reply & Anti-Nuke/Raid",
  "Bot im lặng sau khi trừng phạt (dashboard vẫn ghi nhận case)":
    "Der Bot bleibt nach der Strafe still (das Dashboard erfasst den Fall trotzdem)",
  "Bot không gửi embed nào sau khi trừng phạt (dashboard vẫn ghi nhận case).":
    "Der Bot postet kein Embed nach der Strafe (das Dashboard erfasst den Fall trotzdem).",
  "Bot không gửi heartbeat. Hãy khởi động bot trên host rồi thử khôi phục lại sau khi bot online.":
    "Der Bot sendet keine Heartbeats. Starte den Bot auf dem Host und versuche die Wiederherstellung erneut, sobald er online ist.",
  "Bot lạ": "Unbekannter Bot",
  "Bot vào-rồi-rời": "Bot-Beitritt-und-Abgang",
  "Bot vào-rồi-rời (hit-and-run)": "Bot-Beitritt-und-Abgang (Hit-and-run)",
  "Bot đang học…": "Der Bot lernt…",
  "Báo cáo hàng ngày": "Tagesbericht",
  "Báo cáo khẩn & report": "Dringend-Alarm & Report",
  "Bảng nhiệt & warn": "Heat- & Verwarnungstabelle",
  "Bảo vệ server": "Serverschutz",
  Bật: "An",
  "Bật bảng": "Panel aktivieren",
  "Bật tất cả": "Alle aktivieren",
  "Chưa có sự kiện chống nuke nào được ghi nhận.": "Noch keine Anti-Nuke-Ereignisse aufgezeichnet.",
  "Chặn VPN/Proxy ngay lập tức": "VPN/Proxy sofort blocken",
  "Chặn domain lừa đảo (nitro giả, gift giả…), link IP và file đuôi nguy hiểm (.exe, .scr, .bat…)":
    "Blockt Scam-Domains (Fake-Nitro, Fake-Geschenke…), IP-Links und gefährliche Dateiendungen (.exe, .scr, .bat…)",
  "Chặn link mời Discord": "Discord-Einladungen blocken",
  "Chỉnh trên web, bot áp dụng sau khoảng một phút":
    "Im Web bearbeiten, der Bot übernimmt es in etwa einer Minute",
  "Chọn…": "Wählen…",
  "Chống ban hàng loạt": "Anti-Massen-Ban",
  "Chống kick hàng loạt": "Anti-Massen-Kick",
  "Chống link độc hại & file nguy hiểm": "Bösartige Links & gefährliche Dateien",
  "Chống lặp tin nhắn": "Anti-Doppelnachrichten",
  "Chống raid thành viên": "Anti-Mitglieder-Raid",
  "Chống spam mention": "Anti-Mention-Spam",
  "Chống spam tin nhắn": "Anti-Nachrichten-Spam",
  "Chống spam ảnh & file": "Anti-Bild- & Datei-Spam",
  "Chống spam ảnh/file": "Anti-Bild-/Datei-Spam",
  "Chống thêm bot hàng loạt": "Anti-Massen-Bot-Add",
  "Chống tin rỗng/nhiễu": "Anti-Leer-/Rauschnachrichten",
  "Chống tạo webhook hàng loạt": "Anti-Massen-Webhook-Erstellung",
  "Chống tạo/xóa kênh": "Anti-Kanal-Erstellen/Löschen",
  "Chống tạo/xóa role": "Anti-Rollen-Erstellen/Löschen",
  "Chống tạo/xóa thread": "Anti-Thread-Erstellen/Löschen",
  "Chống xóa tin hàng loạt": "Anti-Massen-Nachrichtenlöschung",
  "Sao lưu toàn bộ server (role, kênh, tin nhắn kèm media, emoji), nén và đẩy lên GitHub Gist, tự động chạy định kỳ 2–30 ngày. Khôi phục sang server khác hoặc nhập trực tiếp file backup của bot nuke (.msc).":
    "Sichert den ganzen Server (Rollen, Kanäle, Nachrichten mit Medien, Emojis), komprimiert und legt ihn in einem GitHub Gist ab, automatisch alle 2–30 Tage. In einen anderen Server wiederherstellen oder die Backup-Datei eines Nuke-Bots (.msc) direkt importieren.",
  "Cách hoạt động": "So funktioniert es",
  "Công cụ Mod": "Mod-Werkzeuge",
  "Cảm xúc": "Emotionen",
  "Cảnh báo": "Verwarnung",
  "Cảnh báo bot lạ": "Alarm bei unbekannten Bots",
  "Cấm thành viên vĩnh viễn": "Mitglied dauerhaft bannen",
  "Cấu hình trên dashboard": "Im Dashboard konfigurieren",
  "Cộng đồng": "Community",
  "Cử chỉ": "Gesten",
  "Danh mục": "Kategorien",
  "Diễn đàn": "Forum",
  "Embed chỉ hiển thị Offender + hành động": "Embed zeigt nur Täter + Aktion",
  "Game & hoạt động": "Spiele & Aktivitäten",
  "Ghi log VPN nhưng không chặn": "VPNs protokollieren, ohne zu blocken",
  "Giai đoạn nhiệt": "Heat-Stufen",
  "Giám sát tự động": "Automatische Überwachung",
  "Gán/gỡ role hàng loạt": "Massen-Rollen-Zuweisung/-Entzug",
  "Gửi cảnh báo riêng (DM) cho thành viên": "Dem Mitglied eine private Verwarnung senden (DM)",
  "Hãy kiểm tra lại file backup hoặc tải lại file khác.":
    "Prüfe die Backup-Datei erneut oder lade eine andere hoch.",
  "Hệ thống nhiệt độ 4 giai đoạn": "4-stufiges Heat-System",
  "Học ngay": "Jetzt lernen",
  "Hồng anh đào, lời chào cơ bản": "Kirschblüte: einfacher Gruß",
  Khác: "Sonstige",
  "Khóa tạm thời (đặt thời lượng bên dưới)": "Vorübergehend sperren (Dauer unten einstellen)",
  "Không có lựa chọn": "Keine Optionen",
  "Không có sự kiện nào khớp với bộ lọc hiện tại.": "Keine Ereignisse passen zum aktuellen Filter.",
  "Không hoạt động": "Inaktiv",
  "Không kiểm tra VPN": "Keine VPN-Prüfung",
  "Kick hàng loạt": "Massen-Kick",
  "Kênh & thread": "Kanäle & Threads",
  "Role · Emoji · Server": "Rollen · Emojis · Server",
  "Kênh log": "Log-Kanal",
  "Kích hoạt khi thành viên tag bot trong tin nhắn.":
    "Löst aus, wenn ein Mitglied den Bot in einer Nachricht taggt.",
  "Kích hoạt khi tin nhắn chứa một trong các từ khóa bên dưới.":
    "Löst aus, wenn eine Nachricht eines der Schlüsselwörter unten enthält.",
  "Lưu cài đặt": "Einstellungen speichern",
  "Lưu phân quyền": "Berechtigungen speichern",
  "Lưu thay đổi": "Änderungen speichern",
  "Lưu webhook": "Webhook speichern",
  "Lưu whitelist": "Whitelist speichern",
  "Moderation lọc nội dung": "Inhalts-Moderation",
  "Module bảo vệ": "Schutzmodule",
  "Module chống nuke": "Anti-Nuke-Module",
  "Màu sắc": "Farbe",
  "Mất kết nối tới máy chủ": "Verbindung zum Server verloren",
  "Mỗi vi phạm cộng điểm nhiệt và tự leo thang hình phạt: cảnh báo qua DM → tạm khóa → kick → ban. Nhiệt giảm dần theo phút, tái phạm trong cửa sổ ngắn bị nhân đôi.":
    "Jede Übertretung addiert Heat und eskaliert die Strafe: DM-Verwarnung → Timeout → Kick → Ban. Heat sinkt pro Minute; Wiederholung im Fenster verdoppelt sie.",
  "Nghi phạm nguồn cơn:": "Wahrscheinlicher Urheber:",
  "Nghiêm ngặt": "Streng",
  "Nội dung nguy hiểm": "Gefährliche Inhalte",
  "Offender + lý do": "Täter + Grund",
  "Offender + lý do + moderator": "Täter + Grund + Moderator",
  "Phát hiện làn sóng thành viên giả mạo tham gia ồ ạt":
    "Erkennt eine Welle gefälschter Konten, die gleichzeitig beitreten",
  "Phát hiện nhiều lượt ban trong thời gian ngắn": "Erkennt viele Bans in kurzer Zeit",
  "Phát hiện nhiều lượt kick thành viên": "Erkennt viele Kicks von Mitgliedern",
  "Phát hiện quét sạch kênh (bulk delete / nuke channel)":
    "Erkennt Kanal-Kahlschläge (Bulk-Löschung / Nuke-Kanal)",
  "Phát hiện spam tag người/role/kênh liên tục trong thời gian ngắn":
    "Erkennt wiederholtes Pingen von Personen/Rollen/Kanälen in kurzer Zeit",
  "Phát hiện spam tạo kênh mới": "Erkennt Spam beim Anlegen neuer Kanäle",
  "Phát hiện spam tạo role mới": "Erkennt Spam beim Anlegen neuer Rollen",
  "Phát hiện spam tạo thread (forum/thread nhiễu loạn)":
    "Erkennt Spam beim Erstellen von Threads (Forum-/Thread-Flut)",
  "Phát hiện spam tạo webhook (kênh đăng webhook giả để phá server)":
    "Erkennt Spam beim Erstellen von Webhooks (falsche Webhooks zum Zerstören des Servers)",
  "Phát hiện spam xóa kênh": "Erkennt Spam beim Löschen von Kanälen",
  "Phát hiện spam xóa role": "Erkennt Spam beim Löschen von Rollen",
  "Phát hiện spam xóa thread (quét sạch diễn đàn/thread)":
    "Erkennt Spam beim Löschen von Threads (Forum-/Thread-Kahlschlag)",
  "Phát hiện spam đổi tên/chủ đề/vị trí kênh (phá hoại giao diện)":
    "Erkennt Spam beim Umbenennen/Ändern von Thema/Position von Kanälen (Layout-Vandalismus)",
  "Phát hiện spam ảnh, file đính kèm liên tục trong thời gian ngắn":
    "Erkennt anhaltenden Bild-/Anhang-Spam in kurzer Zeit",
  "Phát hiện sửa tên/màu/quyền nhiều role (role tampering)":
    "Erkennt Änderungen an Namen/Farben/Rechten vieler Rollen (Rollen-Manipulation)",
  "Phát hiện thành viên gửi quá nhiều tin nhắn trong thời gian ngắn":
    "Erkennt ein Mitglied, das zu viele Nachrichten in kurzer Zeit sendet",
  "Phát hiện tin nhắn chỉ gồm khoảng trắng / ký tự ẩn (zero-width) gây nhiễu kênh":
    "Erkennt Nachrichten nur aus Leerzeichen / unsichtbaren Zeichen (Zero-Width), die Kanäle fluten",
  "Phổ biến": "Beliebt",
  Protogon: "Protogon",
  "Purge tin liên quan": "Zugehörige Nachrichten purgen",
  "Purge toàn bộ tin liên quan": "Alle zugehörigen Nachrichten purgen",
  "Quản lý": "Verwaltung",
  "Raid thành viên": "Mitglieder-Raid",
  "Role, kênh, tin nhắn + media và emoji/sticker đã được tạo lại trên server.":
    "Rollen, Kanäle, Nachrichten + Medien und Emojis/Sticker wurden im Server neu erstellt.",
  "Role, kênh, tin nhắn và emoji/sticker đã được tạo lại theo backup. Kiểm tra embed xác nhận trong kênh log.":
    "Rollen, Kanäle, Nachrichten und Emojis/Sticker wurden nach dem Backup neu erstellt. Prüfe die Bestätigungs-Embed im Log-Kanal.",
  "Role, quyền role và kênh sẽ được tạo lại theo backup. Kết quả sẽ hiện ở đây.":
    "Rollen, Rollenrechte und Kanäle werden nach dem Backup neu erstellt. Das Ergebnis erscheint hier.",
  "Đặt rule theo từ khóa hoặc @mention, chèn {user}, {username}, kèm cooldown chống spam. Bot phản hồi tức thì, đúng giọng điệu của server bạn.":
    "Regeln per Schlüsselwort oder @Mention, mit {user}- und {username}-Platzhaltern und Anti-Spam-Cooldown. Sofortige Antworten im Ton deines Servers.",
  "Server nhỏ": "Kleiner Server",
  "Spam & nhiễu kênh": "Spam & Kanalrauschen",
  "Spam tin dài / lặp nội dung": "Lange / doppelte Nachrichten-Spam",
  "Spam tạo emoji/sticker để lấp đầy slot hoặc chèn ảnh phá hoại":
    "Spam beim Erstellen von Emojis/Stickern, um Slots zu füllen oder Vandalenbilder einzuschleusen",
  Sáng: "Hell",
  "Sân khấu": "Bühne",
  "Sửa bảng reaction role": "Reaktions-Rollen-Panel bearbeiten",
  "Sửa role": "Rolle bearbeiten",
  "Sửa role hàng loạt": "Massen-Rollenbearbeitung",
  "Sửa/đổi tên kênh hàng loạt": "Massen-Kanalumbenennung/-bearbeitung",
  "Tag thành viên": "Mitglieder mentionen",
  "Thay đổi quyền kênh hàng loạt": "Massen-Kanalberechtigungsänderung",
  "Theo dõi": "Folgen",
  Thoại: "Voice",
  "Thành viên & quyền": "Mitglieder & Berechtigungen",
  "Thêm bot": "Bot hinzufügen",
  "Thêm bot hàng loạt": "Massen-Bot-Add",
  'Thêm dòng Reason (để trống → ghi "không có lý do")':
    "Zusatzzeile Grund (leer → als „kein Grund“ vermerkt)",
  "Thêm dòng Responsible moderator (bot tự động = tên bot · mod lệnh = tên người dùng)":
    "Zusatzzeile Verantwortlicher Moderator (automatisch = Bot-Name · manueller Mod = Nutzername)",
  "Thông báo": "Benachrichtigungen",
  "Tin giả blank gây nhiễu": "Blank-Rausch-Fakenachrichten",
  "Trading / tài sản": "Handel / Vermögenswerte",
  "Trực tuyến": "Online",
  "Tên server": "Servername",
  "Tím, chữ GIVEAWAY VIP": "Lila, Schriftzug GIVEAWAY VIP",
  "Tính năng": "Funktionen",
  "Tóm tắt sự kiện, nhiệt và warn gửi thẳng vào kênh log":
    "Ereignis-, Heat- und Verwarnungs-Zusammenfassung direkt in den Log-Kanal",
  "Tạm khóa": "Timeout",
  "Tạm khóa (timeout)": "Vorübergehende Sperre (Timeout)",
  "Tạo bot trên Discord Developer Portal, lấy token và Client ID rồi dán vào mục API Keys của Protogon.":
    "Bot im Discord Developer Portal erstellen, Token und Client ID kopieren und in Protogons API-Schlüssel einfügen.",
  "Tạo bảng": "Panel erstellen",
  "Tạo bảng reaction role": "Reaktions-Rollen-Panel erstellen",
  "Tạo emoji/sticker hàng loạt": "Massen-Emoji/Sticker-Erstellung",
  "Tạo giveaway 🎉": "Giveaway erstellen 🎉",
  "Tạo kênh": "Kanal erstellen",
  "Tạo kênh hàng loạt": "Massen-Kanalerstellung",
  "Tạo link mời hàng loạt": "Massen-Einladungserstellung",
  "Tạo role": "Rolle erstellen",
  "Tạo role hàng loạt": "Massen-Rollenerstellung",
  "Tạo rule": "Regel erstellen",
  "Tạo thread hàng loạt": "Massen-Thread-Erstellung",
  "Tạo webhook hàng loạt": "Massen-Webhook-Erstellung",
  "Tạo ứng dụng Discord": "Discord-Anwendung erstellen",
  "Tải ảnh lên": "Bild hochladen",
  "Tắt bảng": "Panel deaktivieren",
  "Tắt tất cả": "Alle deaktivieren",
  Tối: "Dunkel",
  "Tự cấp quyền": "Selbst erteilte Berechtigungen",
  "Tự cấp quyền quản trị": "Selbst erteilte Admin-Rechte",
  "Tự trả lời thông minh": "Smarte Auto-Antworten",
  "Tự động xóa tin nhắn chứa từ trong danh sách từ ngữ xấu của server":
    "Löscht automatisch Nachrichten mit Wörtern aus der Schimpfwortliste des Servers",
  "Video quá lớn (tối đa 50MB)": "Video zu groß (max. 50 MB)",
  "Vàng, chữ GIVEAWAY SANG TRỌNG": "Gold, Schriftzug GIVEAWAY LUXUS",
  "Văn bản": "Text",
  "Warn tích lũy": "Kumulierte Verwarnungen",
  "Xanh lá, chữ QUÀ TẶNG": "Grün, Schriftzug GESCHENK",
  "Theo dõi từng thành viên, xóa nhiệt bằng một cú nhấn":
    "Jedes Mitglied im Blick, Heat mit einem Klick löschen",
  "Xác nhận": "Bestätigen",
  "Xóa hàng loạt mọi tin nhắn liên quan đến vụ vi phạm (ví dụ: toàn bộ tin spam trong cửa sổ phát hiện)":
    "Löscht im Bulk jede Nachricht, die mit dem Vorfall zusammenhängt (z. B. den gesamten Spam im Erkennungsfenster)",
  "Xóa kênh": "Kanal löschen",
  "Xóa kênh hàng loạt": "Massen-Kanallöschung",
  "Xóa ngay tin nhắn vi phạm tại thời điểm bot nhận ra vi phạm":
    "Löscht die Verstoß-Nachricht sofort, sobald der Bot den Verstoß bemerkt",
  "Xóa role": "Rolle löschen",
  "Xóa role hàng loạt": "Massen-Rollenlöschung",
  "Xóa thread hàng loạt": "Massen-Thread-Löschung",
  "Xóa tin nhắn chứa link mời discord.gg / discord.com/invite":
    "Löscht Nachrichten mit discord.gg- / discord.com/invite-Links",
  "Xóa tin nhắn hàng loạt": "Massen-Nachrichtenlöschung",
  "[đăng-nhập] ": "[Anmeldung] ",
  "ai đó tự gán role Admin/ManageGuild/ManageRoles":
    "wer sich selbst Admin/ManageGuild/ManageRoles gibt",
  "ban thất bại": "Ban fehlgeschlagen",
  "bot đăng cảnh báo kèm chi tiết tài khoản (tuổi acc, tick xác minh, quyền, người thêm). CHỈ CẢNH BÁO, không phạt; kết hợp với module hit-and-run để bắt trọn vòng đời bot nuke":
    "postet der Bot einen Alarm mit Kontodetails (Kontoalter, Verifizierungshäkchen, Rechte, Einlader). NUR ALARM, keine Strafe; mit dem Hit-and-run-Modul kombinieren, um den vollen Nuke-Bot-Lebenszyklus zu erfassen",
  "chưa rõ": "unbekannt",
  "cân bằng, rõ ràng": "ausgewogen, klar",
  "có thể bot đang chạy bản cũ, hãy cập nhật bot lên bản mới nhất rồi thử lại.":
    "läuft der Bot vielleicht auf einer alten Version — aktualisiere ihn und versuche es erneut.",
  "dày dặn, trầm": "satt, dunkel",
  "dùng chung mọi server).": "von allen Servern geteilt).",
  "dấu hiệu kinh điển của bot nuke (dọn dấu vết, né audit log). Chỉ bot KHÔNG xác minh và MỚI vào server mới bị phạt; bot xác minh/ở lại lâu/mod kick bình thường được bỏ qua":
    "die klassische Nuke-Bot-Signatur (Spuren verwischen, Audit-Log meiden). Nur NICHT verifizierte Bots, die GERADE beigetreten sind, werden bestraft; verifizierte Bots, Langzeit-Mitglieder und normale Mod-Kicks bleiben unbehelligt",
  "gán/gỡ role cho nhiều thành viên cùng lúc":
    "weist vielen Mitgliedern gleichzeitig Rollen zu/entzieht sie",
  "hãy khởi động bot trên host rồi tải lại file.":
    "starte den Bot auf dem Host und lade die Datei neu.",
  "hãy kiểm tra bot có online không (tab Giám sát bot).":
    "prüfe, ob der Bot online ist (Tab Bot-Monitor).",
  "khởi động bot trên host rồi bấm Khôi phục lại.":
    "starte den Bot auf dem Host und klicke erneut auf Wiederherstellen.",
  "mời nhiều bot vào server cùng lúc": "lädt viele Bots gleichzeitig in den Server ein",
  "nhẹ nhàng, mờ ảo": "sanft, ätherisch",
  "raid → ban + khóa kênh": "Raid → Ban + Kanalsperre",
  "server lớn kèm tin nhắn có thể mất vài phút; nếu quá lâu hãy cập nhật bot lên bản mới nhất.":
    "große Server mit Nachrichten können einige Minuten dauern; zieht es sich hin, aktualisiere den Bot auf die neueste Version.",
  "sửa overwrite nhiều kênh để khóa mọi người hoặc mở toang":
    "ändert Overwrites vieler Kanäle, um alle auszusperren oder weit offen zu stellen",
  "thử dán đường dẫn ảnh thay thế": "versuche stattdessen eine Bild-URL einzufügen",
  "thử lại": "erneut versuchen",
  "thử lại sau ít phút.": "versuche es in ein paar Minuten erneut.",
  "tin có mention": "Nachrichten mit Mentions",
  "tin có ảnh/file": "Nachrichten mit Bildern/Dateien",
  "tạo nhiều link mời trước khi tràn vào":
    "erstellt viele Einladungslinks, bevor er hineinschwemmt",
  "tối giản tuyệt đối": "absolut minimalistisch",
  "xử lý": "Maßnahme",
  "Áp dụng": "Anwenden",
  "Âm nhạc & giải trí": "Musik & Unterhaltung",
  "Đang bảo vệ server": "Schützt den Server",
  "Đang bật": "Aktiviert",
  "Đang gửi...": "Wird gesendet...",
  "Đang lưu…": "Wird gespeichert…",
  "Đang tạo…": "Wird erstellt…",
  "Đang áp…": "Wird angewendet…",
  "Đuổi thành viên khỏi server": "Mitglied vom Server kicken",
  "Đã ban nguồn cơn:": "Urheber gebannt:",
  "Đã bật DM chào mừng": "Willkommens-DM aktiviert",
  "Đã bật Join Gate": "Join Gate aktiviert",
  "Đã bật bảng": "Panel aktiviert",
  "Đã bật webhook mặc định": "Standard-Webhook aktiviert",
  "Đã bật xác minh thành viên": "Mitgliederverifizierung aktiviert",
  "Đã gửi thành công! Kiểm tra kênh Discord.": "Erfolgreich gesendet! Prüfe den Discord-Kanal.",
  "Đã tắt": "Deaktiviert",
  "Đã tắt DM chào mừng": "Willkommens-DM deaktiviert",
  "Đã tắt Join Gate": "Join Gate deaktiviert",
  "Đã tắt bảng": "Panel deaktiviert",
  "Đã tắt webhook mặc định": "Standard-Webhook deaktiviert",
  "Đã tắt xác minh thành viên": "Mitgliederverifizierung deaktiviert",
  "Đặt mật khẩu": "Passwort setzen",
  "Đồng bộ tự động": "Auto-Sync",
  "Đổi biệt danh hàng loạt": "Massen-Spitznamenänderung",
  "Đổi cấu hình": "Konfigurationsänderung",
  "Đổi cấu hình server": "Server-Konfigurationsänderung",
  "Đổi mật khẩu": "Passwort ändern",
  "Động vật": "Tiere",
  "Đủ N lần warn là tự tăng cấp hình phạt": "N Verwarnungen → Strafe eskaliert automatisch",
  "đen thuần khiết": "reines Schwarz",
  "đã bật": "aktiviert",
  "đã hủy": "abgebrochen",
  "đã kết thúc": "beendet",
  "đổi nickname của nhiều thành viên": "ändert die Spitznamen vieler Mitglieder",
  "đổi tên/icon/bật MFA/giảm verification…":
    "benennt um / ändert das Icon / aktiviert MFA / senkt die Verifizierung…",

  // ── Routentitel (App.tsx, zur Renderzeit in TitleSync übersetzt) ─────────
  "Protogon — Bot Discord tự trả lời & chống nuke/raid":
    "Protogon — Discord-Bot mit Auto-Reply & Anti-Nuke/Raid",
  "Đăng nhập — Protogon": "Anmelden — Protogon",
  "Thống kê nhiệt độ — Protogon": "Heat-Statistik — Protogon",
  "Giám sát bot — Protogon": "Bot-Monitor — Protogon",
  "Quản trị — Protogon": "Administration — Protogon",

  // ── Hinweise in BackupPanel ─────────────────────────────────────────────
  "Bot đang OFFLINE (không nhận được heartbeat) — hãy khởi động bot trên host rồi tải lại file.":
    "Der Bot ist OFFLINE (keine Heartbeats) — starte ihn auf dem Host und lade die Datei neu.",
  "Bot online nhưng chưa xử lý — có thể bot đang chạy bản cũ, hãy cập nhật bot lên bản mới nhất rồi thử lại.":
    "Der Bot ist online, hat aber noch nicht verarbeitet — er läuft vielleicht auf einer alten Version; aktualisiere ihn und versuche es erneut.",
  "Không xác định được trạng thái bot — hãy kiểm tra bot có online không (tab Giám sát bot).":
    "Bot-Status nicht ermittelbar — prüfe, ob er online ist (Tab Bot-Monitor).",
  "Bot đang OFFLINE — khởi động bot trên host rồi bấm Khôi phục lại.":
    "Der Bot ist OFFLINE — starte ihn auf dem Host und klicke erneut auf Wiederherstellen.",
  "Bot online nhưng chưa xử lý xong — server lớn kèm tin nhắn có thể mất vài phút; nếu quá lâu hãy cập nhật bot lên bản mới nhất.":
    "Der Bot ist online, hat aber noch nicht fertig — große Server mit Nachrichten können einige Minuten dauern; zieht es sich hin, aktualisiere den Bot.",
  "Backup (kèm tin nhắn) sẽ được lưu trên Convex và đẩy lên GitHub (token của chủ bot — dùng chung mọi server).":
    "Das Backup (mit Nachrichten) wird in Convex gespeichert und zu GitHub geschoben (Token des Bot-Besitzers — von allen Servern geteilt).",
  "Backup sẽ được lưu trên Convex và đẩy lên GitHub (token của chủ bot — dùng chung mọi server).":
    "Das Backup wird in Convex gespeichert und zu GitHub geschoben (Token des Bot-Besitzers — von allen Servern geteilt).",
  "Không tải file lên được — thử lại": "Datei konnte nicht hochgeladen werden — erneut versuchen",
  "Không nhận được mã file — thử lại": "Keine Datei-ID erhalten — erneut versuchen",
  "Cấu hình đăng nhập chưa hoàn tất — thử lại sau ít phút.":
    "Die Anmeldekonfiguration ist unvollständig — versuche es in ein paar Minuten.",

  // ── Landing: Funktionsbeschreibungen (sections.tsx) ─────────────────────
  "Tự động chặn spam tin nhắn, mention, ảnh/file và link mời Discord, lọc từ ngữ thô tục — song song với hệ thống warn tích lũy leo thang hình phạt.":
    "Blockt Nachrichten-, Mention- und Bild-/Datei-Spam sowie Discord-Einladungen und filtert Schimpfwörter — parallel zur Eskalation über kumulierte Verwarnungen.",
  "Nhận diện domain lừa đảo (nitro giả, gift giả, crypto scam…), link IP và tệp nguy hiểm (.exe, .scr, .bat…) rồi xóa tin nhắn kèm cảnh báo cho mod.":
    "Erkennt Scam-Domains (Fake-Nitro, Fake-Geschenke, Crypto-Scams…), IP-Links und gefährliche Dateien (.exe, .scr, .bat…), löscht die Nachricht und alarmiert deine Mods.",
  "Cổng kiểm soát đầu vào: chặn tài khoản quá mới, không avatar, không huy hiệu và mọi lượt vào khi server đang bị raid — vẫn có danh sách trắng cho người quen.":
    "Ein Eingangs-Checkpoint: blockt zu neue Konten sowie solche ohne Avatar oder Abzeichen und jeden Beitritt während eines Raids — mit Whitelist für Vertraute.",
  "Chống nuke & raid — 24 module": "Anti-Nuke & Raid — 24 Module",
  "Ban/kick hàng loạt, raid thành viên, phá kênh/role, webhook spam, bot hit-and-run, tự cấp quyền quản trị… đều bị phát hiện và xử lý tức thì, kèm khóa kênh tự động khi server bị tấn công.":
    "Massen-Bans/Kicks, Mitglieder-Raids, Kanal-/Rollen-Vandalismus, Webhook-Spam, Hit-and-run-Bots, selbst erteilte Admin-Rechte… alles wird sofort erkannt und behandelt, samt automatischer Kanalsperre beim Angriff.",
  "Đầy đủ /mod timeout · kick · ban · purge cùng các lệnh text !timeout !kick !ban !purge — mọi hành động đều được ghi lại kèm lý do và người thực hiện.":
    "Das volle Set /mod timeout · kick · ban · purge plus die Textbefehle !timeout !kick !ban !purge — jede Aktion mit Grund und Moderator protokolliert.",
  "Nhấn Mời bot và chọn server của bạn — Protogon tạo sẵn cấu hình an toàn với đủ 32 module bật, chỉnh lại bất cứ lúc nào.":
    "Klicke auf Bot einladen und wähle deinen Server — Protogon legt eine sichere Standardkonfiguration mit allen 32 Modulen an; alles lässt sich später anpassen.",
  "Thêm rule trả lời, tinh chỉnh nhiệt độ và warn, bật Join Gate, chọn hình phạt — mọi thay đổi có hiệu lực sau khoảng một phút.":
    "Antwortregeln hinzufügen, Heat und Verwarnungen justieren, Join Gate aktivieren, Strafen wählen — jede Änderung greift in etwa einer Minute.",

  // ── Anti-Nuke-Modulbeschreibungen (constants.ts → ModuleCard) ───────────
  "Permission bombing — sửa overwrite nhiều kênh để khóa mọi người hoặc mở toang":
    "Permission Bombing — ändert Overwrites vieler Kanäle, um alle auszusperren oder weit offen zu stellen",
  "Leo thang đặc quyền — ai đó tự gán role Admin/ManageGuild/ManageRoles":
    "Privilegien-Eskalation — wer sich selbst Admin/ManageGuild/ManageRoles gibt",
  "Role bombing — gán/gỡ role cho nhiều thành viên cùng lúc":
    "Role Bombing — weist vielen Mitgliedern gleichzeitig Rollen zu/entzieht sie",
  "Rename raid — đổi nickname của nhiều thành viên":
    "Rename Raid — ändert die Spitznamen vieler Mitglieder",
  "Bot raid — mời nhiều bot vào server cùng lúc":
    "Bot Raid — lädt viele Bots gleichzeitig in den Server ein",
  "Bot chưa biết được thêm vào server — bot đăng cảnh báo kèm chi tiết tài khoản (tuổi acc, tick xác minh, quyền, người thêm). CHỈ CẢNH BÁO, không phạt; kết hợp với module hit-and-run để bắt trọn vòng đời bot nuke":
    "Ein unbekannter Bot wurde hinzugefügt — der Bot postet einen Alarm mit Kontodetails (Kontoalter, Verifizierungshäkchen, Rechte, Einlader). NUR ALARM, keine Strafe; mit dem Hit-and-run-Modul kombinieren, um den vollen Nuke-Bot-Lebenszyklus zu erfassen",
  "Bot lạ tự rời server ngay sau khi được thêm — dấu hiệu kinh điển của bot nuke (dọn dấu vết, né audit log). Chỉ bot KHÔNG xác minh và MỚI vào server mới bị phạt; bot xác minh/ở lại lâu/mod kick bình thường được bỏ qua":
    "Ein unbekannter Bot verlässt den Server direkt nach dem Hinzufügen — die klassische Nuke-Bot-Signatur (Spuren verwischen, Audit-Log meiden). Nur NICHT verifizierte Bots, die GERADE beigetreten sind, werden bestraft; verifizierte Bots, Langzeit-Mitglieder und normale Mod-Kicks bleiben unbehelligt",
  "Chống raid bằng external app (ứng dụng mở rộng): AI học hỏi các dạng tấn công app ngoài (sockpuppet cài app ồ ạt, app giả mạo/tên scam, spam @everyone/link lừa đảo, webhook spam) và chặn cả biến thể tương tự — raid → ban + khóa kênh":
    "Anti Extern-App-Raid: Die KI lernt Angriffsmuster externer Apps (Sockenpuppen installieren Apps massenhaft, Imitations-/Scam-Apps, @everyone-/Betrugslink-Spam, Webhook-Spam) und blockt auch deren Varianten — Raid → Ban + Kanalsperre",
  "Chuẩn bị raid — tạo nhiều link mời trước khi tràn vào":
    "Raid-Vorbereitung — erstellt viele Einladungslinks, bevor er hineinschwemmt",
  "Phá hoại cấp server — đổi tên/icon/bật MFA/giảm verification…":
    "Serverweites Vandalismus — benennt um / ändert das Icon / aktiviert MFA / senkt die Verifizierung…",
  "Phát hiện spam tin nhắn cực dài hoặc lặp lại nội dung giống hệt — AI phân biệt raid hay cá nhân":
    "Erkennt extrem lange oder identisch duplizierte Nachrichten — die KI unterscheidet Raids von Einzeltätern",

  // ── Graustufen des Server-Themas (SERVER_THEMES.desc) ───────────────────
  "Mặc định — đen thuần khiết": "Standard — reines Schwarz",
  "Xám đậm — dày dặn, trầm": "Dunkelgrau — satt, dunkel",
  "Xám vừa — cân bằng, rõ ràng": "Mittelgrau — ausgewogen, klar",
  "Xám nhạt — nhẹ nhàng, mờ ảo": "Hellgrau — sanft, ätherisch",
  "Xám rất nhạt — tối giản tuyệt đối": "Sehr helles Grau — absolut minimalistisch",

  // ── Anti-Nuke-Preset-Toasts (AntiNukePanel, mit {p0}/{p1}) ──────────────
  'Đã áp preset "{p0}": {p1} module': "Preset „{p0}“ angewendet: {p1} Module",
  "Áp preset thất bại": "Preset konnte nicht angewendet werden",

  // ── Toasts, in Callbacks gebaut (nicht JSX) ─────────────────────────────
  "Lỗi không xác định": "Unbekannter Fehler",
  "Gửi thất bại": "Senden fehlgeschlagen",
  "Tạo thất bại": "Erstellen fehlgeschlagen",
  "Tải file thất bại": "Datei-Upload fehlgeschlagen",
  "Mở khóa thất bại": "Entsperren fehlgeschlagen",
  "Lỗi trao đổi mã OAuth ({p0})": "OAuth-Code-Austausch fehlgeschlagen ({p0})",
  "Không lấy được thông tin user ({p0})": "Nutzerprofil konnte nicht geladen werden ({p0})",
  "Không lấy được danh sách server ({p0})": "Serverliste konnte nicht geladen werden ({p0})",
  "Không thể kết nối tới máy chủ Protogon. Vui lòng thử lại sau.":
    "Protogon-Server nicht erreichbar. Bitte später erneut versuchen.",
  "Thiếu mã xác nhận từ Discord.": "Bestätigungscode von Discord fehlt.",
  "DISCORD_CLIENT_ID chưa được cấu hình trong API Keys.":
    "DISCORD_CLIENT_ID ist unter API-Schlüssel nicht konfiguriert.",
  "Phiên đăng nhập không hợp lệ. Vui lòng thử lại.":
    "Die Anmeldesitzung ist ungültig. Bitte erneut versuchen.",
  "Đã bật toàn bộ chống nuke": "Alle Anti-Nuke-Module aktiviert",
  "Đã tắt toàn bộ chống nuke": "Alle Anti-Nuke-Module deaktiviert",
  "Đã bật chia sẻ threat relay": "Threat-Relay-Freigabe aktiviert",
  "Đã tắt threat relay": "Threat-Relay deaktiviert",
  "Đã bật báo cáo hàng ngày": "Tagesbericht aktiviert",
  "Đã tắt báo cáo hàng ngày": "Tagesbericht deaktiviert",
  "Đã bật cảnh báo khẩn": "Dringend-Alarme aktiviert",
  "Đã tắt cảnh báo khẩn": "Dringend-Alarme deaktiviert",
  "Đã bật ping @everyone": "@everyone-Ping aktiviert",
  "Đã tắt ping @everyone": "@everyone-Ping deaktiviert",
  "Đã bật chế độ an toàn — chỉ phạt khi có đủ bằng chứng":
    "Sicherer Modus aktiviert — straft nur bei soliden Belegen",
  "Đã tắt chế độ an toàn — phạt theo điểm rủi ro":
    "Sicherer Modus deaktiviert — Strafe nach Risikopunkten",
  "Đã bật tự động backup mỗi {p0} ngày": "Automatisches Backup alle {p0} Tage aktiviert",
  "Đã tắt tự động backup": "Automatisches Backup deaktiviert",
  "kênh đã xóa": "Kanal gelöscht",
  // Präfix alter Bot-Daten in Strafprotokollen (action = "Tự động: …").
  "Tự động": "Automatisch",
  "Tự động: ": "Automatisch: ",
  "không rõ": "unbekannt",
  "@thành viên": "@Mitglied",
  "URL webhook không hợp lệ — phải đúng định dạng discord.com/api/webhooks/{id}/{token}":
    "Ungültige Webhook-URL — muss dem Format discord.com/api/webhooks/{id}/{token} entsprechen",
  "Nhập ID Discord hợp lệ (15–20 chữ số), cách nhau bởi dấu phẩy hoặc khoảng trắng.":
    "Gültige Discord-IDs eingeben (15–20 Ziffern), getrennt mit Komma oder Leerzeichen.",
  "✅ Đã gửi yêu cầu — bot sẽ học ngay (xem kết quả trong lịch sử bên dưới, tối đa ~10 phút)":
    "✅ Anfrage gesendet — der Bot lernt sofort (Ergebnis im Verlauf unten, bis zu ~10 Minuten)",
  "Không gửi được yêu cầu": "Anfrage konnte nicht gesendet werden",
  "Bot đang chạy bản cũ ({p0}) nên không xác nhận được kết quả — hãy kiểm tra server trực tiếp và cập nhật bot lên bản mới nhất (v{p1}+) để nhận báo cáo chính xác.":
    "Der Bot läuft auf einer alten Version ({p0}) und kann das Ergebnis nicht bestätigen — prüfe den Server direkt und aktualisiere den Bot (v{p1}+) für genaue Berichte.",
  "Bot đang chạy bản cũ ({p0}) — hãy kiểm tra server trực tiếp và cập nhật bot lên bản mới nhất (v{p1}+).":
    "Der Bot läuft auf einer alten Version ({p0}) — prüfe den Server direkt und aktualisiere den Bot (v{p1}+).",
  "Discord đang gặp sự cố tạm thời (lỗi {p0} từ phía Discord). Vui lòng thử lại sau ít phút — trạng thái: status.discord.com":
    "Discord hat eine vorübergehende Störung (Fehler {p0} auf Discord-Seite). Bitte in ein paar Minuten erneut versuchen — Status: status.discord.com",
  "Đăng nhập thất bại, vui lòng thử lại.": "Anmeldung fehlgeschlagen, bitte erneut versuchen.",
  "Bạn đã xác minh thành công. Chào mừng bạn đến với server!":
    "Du bist erfolgreich verifiziert. Willkommen auf dem Server!",
  "Phạt trực tiếp": "Direkte Strafe",
  "Khóa kênh khi raid": "Kanalsperre bei Raids",
  "Miễn trừ role": "Rollen-Ausnahmen",
  "Kênh log riêng": "Eigener Log-Kanal",
  "Giải đáp tức thì, 24/7 — không cần chờ đợi": "Sofortige Antworten, 24/7 — ohne Wartezeit",
  "Biết rõ từng tính năng & cách cấu hình của Protogon":
    "Kennt jede Protogon-Funktion und ihre Konfiguration",
  "Trả lời rõ ràng, nghiêm túc — trên web lẫn trong dashboard":
    "Antwortet klar und ernsthaft — im Web wie im Dashboard",
  "Khu vực riêng tư dành cho chủ sở hữu bot 🔒": "Privater Bereich für den Bot-Besitzer 🔒",
  "⚡ Bot tự động": "⚡ Automatisch (Bot)",
  "✨ Sang trọng": "✨ Luxuriös",
  "🌐 Tất cả": "🌐 Alle",
  "🎁 Nhanh gọn": "🎁 Schnell & schlank",
  "🎉 Mặc định": "🎉 Standard",
  "📤 Rời server": "📷 Server verlassen",
  "📥 Vào server": "📥 Server beitreten",
  "🛠️ Lệnh mod": "🛠️ Mod-Befehle",
  "🛡️ Chống nuke": "🛡️ Anti-Nuke",
  "Đã bật nhóm ({p0} module)": "Gruppe aktiviert ({p0} Module)",
  "Đã tắt nhóm ({p0} module)": "Gruppe deaktiviert ({p0} Module)",
  'Xóa rule "{p0}"?': "Regel „{p0}“ löschen?",
  "{p}s trước": "vor {p}s",
  "{p}p trước": "vor {p}m",
  "{p} giờ trước": "vor {p} Std.",
  "{p} ngày trước": "vor {p} Tg.",
  "đã ban": "verbannt",
  // ── Rechtstexte (/terms, /privacy, /data-deletion) ──
  "Văn bản pháp lý": "Rechtliches",
  "Cập nhật lần cuối": "Zuletzt aktualisiert",
  "Áp dụng cho": "Gilt für",
  "bot Protogon và dashboard web": "den Protogon-Bot und das Web-Dashboard",
  "Mục lục": "Inhalt",
  "Văn bản khác": "Weitere Dokumente",
  "Về đầu trang": "Nach oben",
  "Cần hỗ trợ thêm?": "Noch Fragen?",
  "Mọi câu hỏi về văn bản này, yêu cầu xoá dữ liệu hoặc báo lỗi bot đều được tiếp nhận trong kênh hỗ trợ của cộng đồng.":
    "Fragen zu diesem Dokument, Löschanfragen und Fehlerberichte zum Bot nehmen wir im Support-Kanal der Community entgegen.",
  "Điều khoản sử dụng": "Nutzungsbedingungen",
  "Chính sách quyền riêng tư": "Datenschutzerklärung",
  "Lưu trữ & xoá dữ liệu": "Aufbewahrung & Löschung",
  "Điều khoản sử dụng — Protogon": "Nutzungsbedingungen — Protogon",
  "Chính sách quyền riêng tư — Protogon": "Datenschutzerklärung — Protogon",
  "Lưu trữ & xoá dữ liệu — Protogon": "Aufbewahrung & Löschung — Protogon",
};
